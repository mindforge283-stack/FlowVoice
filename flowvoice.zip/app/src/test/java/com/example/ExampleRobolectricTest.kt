package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.local.DictionaryWordEntity
import com.example.data.local.SettingsStore
import com.example.data.local.SnippetEntity
import com.example.data.local.TranscriptEntity
import com.example.data.model.ToneMode
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches FlowVoice`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("FlowVoice", appName)
    }

    @Test
    fun `room database persists transcripts dictionary and snippets`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()

        val dao = db.flowVoiceDao()
        dao.insertTranscript(
            TranscriptEntity(
                title = "Standup Note",
                rawTranscript = "um let's meet at 5 actually make it 6",
                formattedText = "Let's meet at 6.",
                toneModeId = ToneMode.CLEAN_NATURAL.id,
                durationSeconds = 4
            )
        )
        dao.insertDictionaryWord(DictionaryWordEntity(word = "Kubernetes", phoneticHint = "tech"))
        dao.insertSnippet(SnippetEntity(triggerPhrase = "my email", expansionText = "alex@flowvoice.app"))

        val transcripts = dao.observeTranscripts().first()
        val words = dao.getAllDictionaryWordsOnce()
        val snippets = dao.getAllSnippetsOnce()

        assertEquals(1, transcripts.size)
        assertEquals("Let's meet at 6.", transcripts.first().formattedText)
        assertEquals(1, words.size)
        assertEquals("Kubernetes", words.first().word)
        assertEquals(1, snippets.size)
        assertEquals("alex@flowvoice.app", snippets.first().expansionText)

        db.close()
    }

    @Test
    fun `settings store persists tone mode and preferences`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val store = SettingsStore.getInstance(context)

        store.setToneMode(ToneMode.FORMAL_EMAIL)
        store.setAutoCopyEnabled(false)

        val current = store.getCurrentSettings()
        assertEquals(ToneMode.FORMAL_EMAIL, current.selectedToneMode)
        assertFalse(current.autoCopyEnabled)

        store.setAutoCopyEnabled(true)
        assertTrue(store.getCurrentSettings().autoCopyEnabled)
    }
}
