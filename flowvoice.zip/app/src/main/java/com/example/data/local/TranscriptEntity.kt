package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transcripts")
data class TranscriptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val rawTranscript: String,
    val formattedText: String,
    val toneModeId: String,
    val durationSeconds: Int,
    val createdAt: Long = System.currentTimeMillis(),
    val isPinned: Boolean = false
)
