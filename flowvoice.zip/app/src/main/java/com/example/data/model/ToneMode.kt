package com.example.data.model

enum class ToneMode(
    val id: String,
    val label: String,
    val shortLabel: String,
    val description: String,
    val promptInstruction: String
) {
    CLEAN_NATURAL(
        id = "clean_natural",
        label = "Clean & Natural",
        shortLabel = "Clean",
        description = "Polished prose with natural phrasing and crisp punctuation.",
        promptInstruction = "Produce clean, natural, well-punctuated prose that preserves the speaker's authentic voice and meaning while fixing grammar and sentence flow."
    ),
    FORMAL_EMAIL(
        id = "formal_email",
        label = "Formal Email",
        shortLabel = "Email",
        description = "Structured professional email with greeting and clear sign-off.",
        promptInstruction = "Format as a clear, polite, professional email. Include an appropriate greeting (if implied or natural), well-structured paragraphs, and a concise sign-off if appropriate for an email."
    ),
    CASUAL_CHAT(
        id = "casual_chat",
        label = "Casual Chat",
        shortLabel = "Chat",
        description = "Relaxed, conversational message ideal for Slack or WhatsApp.",
        promptInstruction = "Format as a friendly, relaxed, concise chat message suitable for WhatsApp, Slack, or text messaging. Keep it natural and conversational without stiff formality."
    ),
    BULLET_POINTS(
        id = "bullet_points",
        label = "Bullet Points",
        shortLabel = "Bullets",
        description = "Scannable bulleted list highlighting key points and actions.",
        promptInstruction = "Organize the dictation into clear, scannable bullet points using '• ' at the start of each line. Group related thoughts cleanly and keep each bullet concise."
    );

    companion object {
        fun fromId(id: String?): ToneMode {
            return entries.firstOrNull { it.id == id } ?: CLEAN_NATURAL
        }
    }
}
