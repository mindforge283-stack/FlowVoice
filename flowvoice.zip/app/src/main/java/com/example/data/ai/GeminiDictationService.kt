package com.example.data.ai

import android.util.Log
import com.example.data.local.DictionaryWordEntity
import com.example.data.local.SnippetEntity
import com.example.data.model.ToneMode
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

data class DictationAiResult(
    val title: String,
    val rawTranscript: String,
    val formattedText: String
)

class GeminiDictationService {
    companion object {
        private const val TAG = "GeminiDictationService"
        private const val MODEL_NAME = "gemini-3.8-flash"
        private const val TIMEOUT_MS = 60_000L
    }

    private val responseSchema = Schema.obj(
        properties = mapOf(
            "title" to Schema.string(description = "A concise 2 to 5 word summary title of the dictation."),
            "rawTranscript" to Schema.string(description = "Accurate transcript of what was spoken, respecting custom dictionary spellings."),
            "formattedText" to Schema.string(description = "The cleaned, polished, formatted text ready to paste according to the requested tone and rules.")
        )
    )

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                temperature = 0.25f
                responseMimeType = "application/json"
                responseSchema = this@GeminiDictationService.responseSchema
            }
        )
    }

    suspend fun transcribeAndFormatAudio(
        audioWavBytes: ByteArray,
        toneMode: ToneMode,
        dictionaryWords: List<DictionaryWordEntity>,
        snippets: List<SnippetEntity>,
        removeFillers: Boolean,
        smartCorrections: Boolean
    ): Result<DictationAiResult> {
        if (audioWavBytes.size <= 44) {
            return Result.failure(IllegalArgumentException("No audio was captured. Please speak clearly and try again."))
        }

        val instructions = buildInstructions(
            toneMode = toneMode,
            dictionaryWords = dictionaryWords,
            snippets = snippets,
            removeFillers = removeFillers,
            smartCorrections = smartCorrections,
            isTextReformat = false
        )

        return try {
            val response = withTimeout(TIMEOUT_MS) {
                model.generateContent(
                    content {
                        inlineData(audioWavBytes, "audio/wav")
                        text(instructions)
                    }
                )
            }
            parseResponse(response.text)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Audio transcription timed out", e)
            Result.failure(Exception("Gemini request timed out after 60 seconds. Please try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini audio dictation failed", e)
            Result.failure(Exception(e.localizedMessage ?: "Failed to transcribe audio with Gemini."))
        }
    }

    suspend fun reformatText(
        sourceText: String,
        toneMode: ToneMode,
        dictionaryWords: List<DictionaryWordEntity>,
        snippets: List<SnippetEntity>,
        removeFillers: Boolean,
        smartCorrections: Boolean
    ): Result<DictationAiResult> {
        val cleanedInput = sourceText.trim()
        if (cleanedInput.isEmpty()) {
            return Result.failure(IllegalArgumentException("Cannot format empty text."))
        }

        val instructions = buildInstructions(
            toneMode = toneMode,
            dictionaryWords = dictionaryWords,
            snippets = snippets,
            removeFillers = removeFillers,
            smartCorrections = smartCorrections,
            isTextReformat = true
        )

        return try {
            val response = withTimeout(TIMEOUT_MS) {
                model.generateContent(
                    content {
                        text(
                            """
                            $instructions

                            INPUT TEXT TO CLEAN & FORMAT:
                            $cleanedInput
                            """.trimIndent()
                        )
                    }
                )
            }
            parseResponse(response.text, fallbackRaw = cleanedInput)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Text reformatting timed out", e)
            Result.failure(Exception("Gemini reformat timed out after 60 seconds. Please try again."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini text reformat failed", e)
            Result.failure(Exception(e.localizedMessage ?: "Failed to format text with Gemini."))
        }
    }

    private fun parseResponse(jsonString: String?, fallbackRaw: String = ""): Result<DictationAiResult> {
        if (jsonString.isNullOrBlank()) {
            return Result.failure(IllegalStateException("Gemini returned an empty response."))
        }
        return try {
            val json = JSONObject(jsonString)
            val title = json.optString("title", "Voice Note").ifBlank { "Voice Note" }
            val raw = json.optString("rawTranscript", fallbackRaw).ifBlank { fallbackRaw }
            val formatted = json.optString("formattedText", "").trim()
            if (formatted.isEmpty()) {
                Result.failure(IllegalStateException("Could not detect clear speech. Please try again."))
            } else {
                Result.success(
                    DictationAiResult(
                        title = title,
                        rawTranscript = raw,
                        formattedText = formatted
                    )
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to parse Gemini JSON response: $jsonString", e)
            Result.failure(IllegalStateException("Unexpected response format from Gemini."))
        }
    }

    private fun buildInstructions(
        toneMode: ToneMode,
        dictionaryWords: List<DictionaryWordEntity>,
        snippets: List<SnippetEntity>,
        removeFillers: Boolean,
        smartCorrections: Boolean,
        isTextReformat: Boolean
    ): String {
        val dictionarySection = if (dictionaryWords.isEmpty()) {
            "None provided."
        } else {
            dictionaryWords.joinToString("\n") { item ->
                if (item.phoneticHint.isNotBlank()) {
                    "- ${item.word} (hint/context: ${item.phoneticHint})"
                } else {
                    "- ${item.word}"
                }
            }
        }

        val snippetsSection = if (snippets.isEmpty()) {
            "None provided."
        } else {
            snippets.joinToString("\n") { snippet ->
                "- When speaker says \"${snippet.triggerPhrase}\" -> replace/expand with exact text: \"${snippet.expansionText}\""
            }
        }

        val fillerRule = if (removeFillers) {
            "- Remove all verbal filler words and false starts (e.g., \"um\", \"uh\", \"er\", \"like\" when used as filler, \"you know\", \"I mean\", \"basically\" when redundant)."
        } else {
            "- Preserve natural phrasing while fixing punctuation and capitalization."
        }

        val correctionRule = if (smartCorrections) {
            "- Resolve self-corrections seamlessly so only the speaker's final intended statement remains (e.g., \"meet at 5, actually make it 6\" -> \"meet at 6\"; \"send it to John, no wait, Sarah\" -> \"send it to Sarah\")."
        } else {
            "- Do not rewrite spoken words except for spelling and punctuation."
        }

        val taskLead = if (isTextReformat) {
            "You are FlowVoice, an elite AI dictation editor. Clean, correct, and reformat the provided text."
        } else {
            "You are FlowVoice, an elite AI voice-to-text dictation engine. Listen carefully to the attached audio recording, transcribe it accurately, and format it cleanly."
        }

        return """
            $taskLead

            STRICT RULES:
            $fillerRule
            $correctionRule
            - Fix all punctuation, capitalization, grammar, numbers, dates, and formatting (including spoken lists or bullet points when appropriate).
            - Do NOT invent facts or add conversational commentary like "Here is your formatted text". Output ONLY the cleaned dictation in `formattedText`.
            - If no intelligible speech is present in audio, return an empty string for `formattedText`.

            TARGET TONE & STYLE (${toneMode.label}):
            ${toneMode.promptInstruction}

            PERSONAL DICTIONARY (spell these names/terms exactly as shown):
            $dictionarySection

            VOICE SHORTCUT SNIPPETS (expand matching spoken phrases verbatim):
            $snippetsSection
        """.trimIndent()
    }
}
