package com.example.data.local

import kotlinx.coroutines.flow.Flow

class FlowVoiceRepository(private val dao: FlowVoiceDao) {
    val transcripts: Flow<List<TranscriptEntity>> = dao.observeTranscripts()
    val dictionaryWords: Flow<List<DictionaryWordEntity>> = dao.observeDictionaryWords()
    val snippets: Flow<List<SnippetEntity>> = dao.observeSnippets()

    suspend fun saveTranscript(transcript: TranscriptEntity): Long {
        return dao.insertTranscript(transcript)
    }

    suspend fun updateTranscript(transcript: TranscriptEntity) {
        dao.updateTranscript(transcript)
    }

    suspend fun deleteTranscript(id: Long) {
        dao.deleteTranscriptById(id)
    }

    suspend fun clearHistory() {
        dao.clearAllTranscripts()
    }

    suspend fun getDictionaryWordsSnapshot(): List<DictionaryWordEntity> {
        return dao.getAllDictionaryWordsOnce()
    }

    suspend fun addDictionaryWord(word: String, phoneticHint: String) {
        val trimmed = word.trim()
        if (trimmed.isNotEmpty()) {
            dao.insertDictionaryWord(
                DictionaryWordEntity(
                    word = trimmed,
                    phoneticHint = phoneticHint.trim()
                )
            )
        }
    }

    suspend fun deleteDictionaryWord(id: Long) {
        dao.deleteDictionaryWordById(id)
    }

    suspend fun getSnippetsSnapshot(): List<SnippetEntity> {
        return dao.getAllSnippetsOnce()
    }

    suspend fun addSnippet(triggerPhrase: String, expansionText: String) {
        val trigger = triggerPhrase.trim()
        val expansion = expansionText.trim()
        if (trigger.isNotEmpty() && expansion.isNotEmpty()) {
            dao.insertSnippet(
                SnippetEntity(
                    triggerPhrase = trigger,
                    expansionText = expansion
                )
            )
        }
    }

    suspend fun updateSnippet(snippet: SnippetEntity) {
        dao.updateSnippet(snippet)
    }

    suspend fun deleteSnippet(id: Long) {
        dao.deleteSnippetById(id)
    }
}
