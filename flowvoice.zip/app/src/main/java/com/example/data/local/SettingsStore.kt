package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.ToneMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class UserSettings(
    val selectedToneMode: ToneMode = ToneMode.CLEAN_NATURAL,
    val autoCopyEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val removeFillersEnabled: Boolean = true,
    val smartCorrectionsEnabled: Boolean = true,
    val overlayRunning: Boolean = false
)

class SettingsStore(context: Context) {
    private val prefs: SharedPreferences = context.applicationContext.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<UserSettings> = _settings.asStateFlow()

    private fun loadSettings(): UserSettings {
        return UserSettings(
            selectedToneMode = ToneMode.fromId(prefs.getString(KEY_TONE_MODE, ToneMode.CLEAN_NATURAL.id)),
            autoCopyEnabled = prefs.getBoolean(KEY_AUTO_COPY, true),
            hapticsEnabled = prefs.getBoolean(KEY_HAPTICS, true),
            removeFillersEnabled = prefs.getBoolean(KEY_REMOVE_FILLERS, true),
            smartCorrectionsEnabled = prefs.getBoolean(KEY_SMART_CORRECTIONS, true),
            overlayRunning = prefs.getBoolean(KEY_OVERLAY_RUNNING, false)
        )
    }

    fun getCurrentSettings(): UserSettings = loadSettings()

    fun setToneMode(toneMode: ToneMode) {
        prefs.edit().putString(KEY_TONE_MODE, toneMode.id).apply()
        _settings.update { it.copy(selectedToneMode = toneMode) }
    }

    fun setAutoCopyEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_COPY, enabled).apply()
        _settings.update { it.copy(autoCopyEnabled = enabled) }
    }

    fun setHapticsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_HAPTICS, enabled).apply()
        _settings.update { it.copy(hapticsEnabled = enabled) }
    }

    fun setRemoveFillersEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_REMOVE_FILLERS, enabled).apply()
        _settings.update { it.copy(removeFillersEnabled = enabled) }
    }

    fun setSmartCorrectionsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SMART_CORRECTIONS, enabled).apply()
        _settings.update { it.copy(smartCorrectionsEnabled = enabled) }
    }

    fun setOverlayRunning(running: Boolean) {
        prefs.edit().putBoolean(KEY_OVERLAY_RUNNING, running).apply()
        _settings.update { it.copy(overlayRunning = running) }
    }

    companion object {
        private const val PREFS_NAME = "flowvoice_settings"
        private const val KEY_TONE_MODE = "tone_mode"
        private const val KEY_AUTO_COPY = "auto_copy"
        private const val KEY_HAPTICS = "haptics"
        private const val KEY_REMOVE_FILLERS = "remove_fillers"
        private const val KEY_SMART_CORRECTIONS = "smart_corrections"
        private const val KEY_OVERLAY_RUNNING = "overlay_running"

        @Volatile
        private var INSTANCE: SettingsStore? = null

        fun getInstance(context: Context): SettingsStore {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SettingsStore(context).also { INSTANCE = it }
            }
        }
    }
}
