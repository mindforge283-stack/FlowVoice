package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface FlowVoiceDao {
    @Query("SELECT * FROM transcripts ORDER BY isPinned DESC, createdAt DESC")
    fun observeTranscripts(): Flow<List<TranscriptEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTranscript(transcript: TranscriptEntity): Long

    @Update
    suspend fun updateTranscript(transcript: TranscriptEntity)

    @Query("DELETE FROM transcripts WHERE id = :id")
    suspend fun deleteTranscriptById(id: Long)

    @Query("DELETE FROM transcripts")
    suspend fun clearAllTranscripts()

    @Query("SELECT * FROM dictionary_words ORDER BY createdAt DESC")
    fun observeDictionaryWords(): Flow<List<DictionaryWordEntity>>

    @Query("SELECT * FROM dictionary_words ORDER BY createdAt DESC")
    suspend fun getAllDictionaryWordsOnce(): List<DictionaryWordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDictionaryWord(word: DictionaryWordEntity): Long

    @Query("DELETE FROM dictionary_words WHERE id = :id")
    suspend fun deleteDictionaryWordById(id: Long)

    @Query("SELECT * FROM snippets ORDER BY createdAt DESC")
    fun observeSnippets(): Flow<List<SnippetEntity>>

    @Query("SELECT * FROM snippets ORDER BY createdAt DESC")
    suspend fun getAllSnippetsOnce(): List<SnippetEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnippet(snippet: SnippetEntity): Long

    @Update
    suspend fun updateSnippet(snippet: SnippetEntity)

    @Query("DELETE FROM snippets WHERE id = :id")
    suspend fun deleteSnippetById(id: Long)
}
