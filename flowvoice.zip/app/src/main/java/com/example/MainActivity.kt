package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color as AndroidColor
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.rounded.BubbleChart
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.DictateScreen
import com.example.ui.screens.DictionarySettingsScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.ElectricIndigoBright
import com.example.ui.theme.ElectricIndigoContainer
import com.example.ui.theme.FlowVoiceTheme
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftSlateText
import com.example.ui.viewmodel.FlowVoiceViewModel
import com.example.util.ClipboardHelper

private enum class AppTab(
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    DICTATE(R.string.nav_dictate, Icons.Rounded.Mic, Icons.Outlined.Mic, "nav_dictate"),
    HISTORY(R.string.nav_history, Icons.Rounded.History, Icons.Outlined.History, "nav_history"),
    DICTIONARY_SETTINGS(
        R.string.nav_dictionary_settings,
        Icons.Rounded.MenuBook,
        Icons.Outlined.MenuBook,
        "nav_dictionary_settings"
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before any UI or ViewModels
        configureAppCheck(this, intent)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AndroidColor.TRANSPARENT)
        )

        setContent {
            FlowVoiceTheme {
                FlowVoiceApp()
            }
        }
    }
}

@Composable
fun FlowVoiceApp(
    viewModel: FlowVoiceViewModel = viewModel()
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val stage by viewModel.dictationStage.collectAsStateWithLifecycle()
    val transcripts by viewModel.transcripts.collectAsStateWithLifecycle()
    val dictionaryWords by viewModel.dictionaryWords.collectAsStateWithLifecycle()
    val snippets by viewModel.snippets.collectAsStateWithLifecycle()
    val waveform by viewModel.waveform.collectAsStateWithLifecycle()
    val currentAmplitude by viewModel.currentAmplitude.collectAsStateWithLifecycle()
    val elapsedSeconds by viewModel.elapsedSeconds.collectAsStateWithLifecycle()
    val snackbarMessage by viewModel.snackbarMessage.collectAsStateWithLifecycle()
    val reformattingHistoryId by viewModel.reformattingHistoryId.collectAsStateWithLifecycle()

    var selectedTab by rememberSaveable { mutableStateOf(AppTab.DICTATE) }
    val snackbarHostState = remember { SnackbarHostState() }

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var hasOverlayPermission by remember {
        mutableStateOf(ClipboardHelper.canDrawOverlays(context))
    }

    var showMicPermissionDialog by remember { mutableStateOf(false) }
    var micPermanentlyDenied by remember { mutableStateOf(false) }
    var showOverlayPermissionDialog by remember { mutableStateOf(false) }
    var pendingOverlayStartAfterPermission by remember { mutableStateOf(false) }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        // Foreground microphone service starts even if notifications are declined
        viewModel.startFloatingOverlay()
    }

    fun launchOverlayWithNotificationCheck() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            viewModel.startFloatingOverlay()
        }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasMicPermission = granted
        if (granted) {
            micPermanentlyDenied = false
            showMicPermissionDialog = false
            if (pendingOverlayStartAfterPermission) {
                if (ClipboardHelper.canDrawOverlays(context)) {
                    pendingOverlayStartAfterPermission = false
                    launchOverlayWithNotificationCheck()
                } else {
                    showOverlayPermissionDialog = true
                }
            }
        } else {
            val activity = context as? ComponentActivity
            val canShowRationale = activity?.let {
                ActivityCompat.shouldShowRequestPermissionRationale(it, Manifest.permission.RECORD_AUDIO)
            } ?: true
            micPermanentlyDenied = !canShowRationale
            showMicPermissionDialog = true
        }
    }

    // Refresh permissions when returning from Android system Settings
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasMicPermission = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED
                hasOverlayPermission = ClipboardHelper.canDrawOverlays(context)

                if (pendingOverlayStartAfterPermission && hasMicPermission && hasOverlayPermission) {
                    pendingOverlayStartAfterPermission = false
                    showOverlayPermissionDialog = false
                    launchOverlayWithNotificationCheck()
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    LaunchedEffect(snackbarMessage) {
        snackbarMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.consumeSnackbar()
        }
    }

    BackHandler(enabled = selectedTab != AppTab.DICTATE) {
        selectedTab = AppTab.DICTATE
    }

    fun handleToggleOverlay() {
        if (settings.overlayRunning) {
            viewModel.stopFloatingOverlay()
            return
        }
        if (!hasMicPermission) {
            pendingOverlayStartAfterPermission = true
            showMicPermissionDialog = true
            return
        }
        if (!ClipboardHelper.canDrawOverlays(context)) {
            pendingOverlayStartAfterPermission = true
            showOverlayPermissionDialog = true
            return
        }
        launchOverlayWithNotificationCheck()
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useNavigationRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = ObsidianBackground,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = {
                SnackbarHost(hostState = snackbarHostState) { data ->
                    Snackbar(
                        snackbarData = data,
                        containerColor = ObsidianSurfaceElevated,
                        contentColor = PureWhite,
                        actionColor = ElectricIndigoBright,
                        shape = RoundedCornerShape(14.dp)
                    )
                }
            },
            bottomBar = {
                if (!useNavigationRail) {
                    NavigationBar(
                        containerColor = ObsidianSurface,
                        tonalElevation = 0.dp
                    ) {
                        AppTab.entries.forEach { tab ->
                            val selected = selectedTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { selectedTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = stringResource(tab.labelRes)
                                    )
                                },
                                label = { Text(stringResource(tab.labelRes)) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ElectricIndigoBright,
                                    selectedTextColor = PureWhite,
                                    indicatorColor = ElectricIndigoContainer,
                                    unselectedIconColor = SoftSlateText,
                                    unselectedTextColor = SoftSlateText
                                ),
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useNavigationRail) {
                    NavigationRail(
                        containerColor = ObsidianSurface,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Spacer(modifier = Modifier.weight(1f))
                        AppTab.entries.forEach { tab ->
                            val selected = selectedTab == tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { selectedTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = stringResource(tab.labelRes)
                                    )
                                },
                                label = { Text(stringResource(tab.labelRes)) },
                                colors = NavigationRailItemDefaults.colors(
                                    selectedIconColor = ElectricIndigoBright,
                                    selectedTextColor = PureWhite,
                                    indicatorColor = ElectricIndigoContainer,
                                    unselectedIconColor = SoftSlateText,
                                    unselectedTextColor = SoftSlateText
                                ),
                                modifier = Modifier.testTag(tab.testTag)
                            )
                        }
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }

                when (selectedTab) {
                    AppTab.DICTATE -> {
                        DictateScreen(
                            stage = stage,
                            settings = settings,
                            waveform = waveform,
                            currentAmplitude = currentAmplitude,
                            elapsedSeconds = elapsedSeconds,
                            dictionaryCount = dictionaryWords.size,
                            snippetCount = snippets.size,
                            hasMicPermission = hasMicPermission,
                            onRequestMicPermission = { showMicPermissionDialog = true },
                            onStartRecording = { viewModel.startRecording(locked = false) },
                            onDragLockRecording = { viewModel.lockRecording() },
                            onQuickTapLockRecording = { viewModel.lockRecording() },
                            onStopAndFormat = { viewModel.stopAndFormatRecording() },
                            onCancelRecording = { viewModel.cancelRecording() },
                            onSelectToneMode = { viewModel.selectToneMode(it) },
                            onFormatManualText = { viewModel.formatManualText(it) },
                            onCopyText = { viewModel.copyText(it) },
                            onResetStage = { viewModel.resetDictationStage() },
                            onToggleOverlay = { handleToggleOverlay() },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    AppTab.HISTORY -> {
                        HistoryScreen(
                            transcripts = transcripts,
                            reformattingId = reformattingHistoryId,
                            onCopyText = { viewModel.copyText(it) },
                            onReformatTranscript = { transcript, tone ->
                                viewModel.reformatHistoryTranscript(transcript, tone)
                            },
                            onTogglePin = { viewModel.togglePinTranscript(it) },
                            onDeleteTranscript = { viewModel.deleteTranscript(it) },
                            onClearAll = { viewModel.clearAllHistory() },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    AppTab.DICTIONARY_SETTINGS -> {
                        DictionarySettingsScreen(
                            dictionaryWords = dictionaryWords,
                            snippets = snippets,
                            settings = settings,
                            hasMicPermission = hasMicPermission,
                            hasOverlayPermission = hasOverlayPermission,
                            onAddDictionaryWord = { word, hint ->
                                viewModel.addDictionaryWord(word, hint)
                            },
                            onDeleteDictionaryWord = { viewModel.deleteDictionaryWord(it) },
                            onAddSnippet = { trigger, expansion ->
                                viewModel.addSnippet(trigger, expansion)
                            },
                            onDeleteSnippet = { viewModel.deleteSnippet(it) },
                            onToggleOverlay = { handleToggleOverlay() },
                            onRequestMicPermission = { showMicPermissionDialog = true },
                            onRequestOverlayPermission = {
                                pendingOverlayStartAfterPermission = true
                                showOverlayPermissionDialog = true
                            },
                            onSetAutoCopy = { viewModel.setAutoCopyEnabled(it) },
                            onSetRemoveFillers = { viewModel.setRemoveFillersEnabled(it) },
                            onSetSmartCorrections = { viewModel.setSmartCorrectionsEnabled(it) },
                            onSetHaptics = { viewModel.setHapticsEnabled(it) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }

    if (showMicPermissionDialog) {
        AlertDialog(
            onDismissRequest = {
                showMicPermissionDialog = false
                pendingOverlayStartAfterPermission = false
            },
            containerColor = ObsidianSurface,
            titleContentColor = PureWhite,
            textContentColor = SoftSlateText,
            icon = {
                Icon(
                    imageVector = Icons.Rounded.Mic,
                    contentDescription = null,
                    tint = ElectricIndigoBright
                )
            },
            title = { Text(stringResource(R.string.perm_mic_title)) },
            text = {
                Text(
                    if (micPermanentlyDenied) {
                        "Microphone permission was denied. Open App Settings -> Permissions -> Microphone to allow voice recording."
                    } else {
                        stringResource(R.string.perm_mic_body)
                    }
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showMicPermissionDialog = false
                        if (micPermanentlyDenied) {
                            context.startActivity(ClipboardHelper.createAppSettingsIntent(context))
                        } else {
                            micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo)
                ) {
                    Text(
                        if (micPermanentlyDenied) {
                            stringResource(R.string.perm_settings_button)
                        } else {
                            stringResource(R.string.perm_mic_button)
                        }
                    )
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showMicPermissionDialog = false
                        pendingOverlayStartAfterPermission = false
                    }
                ) {
                    Text("Not Now", color = SoftSlateText)
                }
            }
        )
    }

    if (showOverlayPermissionDialog) {
        AlertDialog(
            onDismissRequest = {
                showOverlayPermissionDialog = false
                pendingOverlayStartAfterPermission = false
            },
            containerColor = ObsidianSurface,
            titleContentColor = PureWhite,
            textContentColor = SoftSlateText,
            icon = {
                Icon(
                    imageVector = Icons.Rounded.BubbleChart,
                    contentDescription = null,
                    tint = ElectricIndigoBright
                )
            },
            title = { Text(stringResource(R.string.perm_overlay_title)) },
            text = { Text(stringResource(R.string.perm_overlay_body)) },
            confirmButton = {
                Button(
                    onClick = {
                        showOverlayPermissionDialog = false
                        context.startActivity(ClipboardHelper.createOverlayPermissionIntent(context))
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo)
                ) {
                    Text(stringResource(R.string.perm_overlay_button))
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showOverlayPermissionDialog = false
                        pendingOverlayStartAfterPermission = false
                    }
                ) {
                    Text("Cancel", color = SoftSlateText)
                }
            }
        )
    }
}
