package com.example.overlay

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.MainActivity
import com.example.R
import com.example.audio.AudioRecorderEngine
import com.example.data.ai.GeminiDictationService
import com.example.data.local.AppDatabase
import com.example.data.local.FlowVoiceRepository
import com.example.data.local.SettingsStore
import com.example.data.local.TranscriptEntity
import com.example.util.ClipboardHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

class FloatingOverlayService : Service() {

    companion object {
        private const val TAG = "FloatingOverlayService"
        private const val CHANNEL_ID = "flowvoice_overlay_channel"
        private const val NOTIFICATION_ID = 4102
        const val ACTION_START = "com.example.overlay.ACTION_START"
        const val ACTION_STOP = "com.example.overlay.ACTION_STOP"

        fun start(context: Context) {
            val intent = Intent(context, FloatingOverlayService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingOverlayService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private enum class BubbleState {
        IDLE, RECORDING, FORMATTING, COPIED
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var windowManager: WindowManager
    private lateinit var settingsStore: SettingsStore
    private lateinit var repository: FlowVoiceRepository
    private val geminiService = GeminiDictationService()
    private val audioEngine = AudioRecorderEngine()

    private var bubbleContainer: FrameLayout? = null
    private var bubbleCircle: FrameLayout? = null
    private var pulseRingView: View? = null
    private var bubbleIcon: ImageView? = null
    private var bubbleSpinner: ProgressBar? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var pulseAnimator: ObjectAnimator? = null

    private var resultCardContainer: LinearLayout? = null
    private var autoHideResultJob: Job? = null

    private var bubbleState = BubbleState.IDLE

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        settingsStore = SettingsStore.getInstance(applicationContext)
        val dao = AppDatabase.getInstance(applicationContext).flowVoiceDao()
        repository = FlowVoiceRepository(dao)

        createNotificationChannel()
        val notification = buildNotification()
        val fgType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, fgType)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (!Settings.canDrawOverlays(this)) {
            Log.w(TAG, "Overlay permission missing, stopping service.")
            settingsStore.setOverlayRunning(false)
            stopSelf()
            return START_NOT_STICKY
        }

        if (bubbleContainer == null) {
            showBubbleOverlay()
        }
        settingsStore.setOverlayRunning(true)
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        settingsStore.setOverlayRunning(false)
        autoHideResultJob?.cancel()
        pulseAnimator?.cancel()
        serviceScope.launch {
            audioEngine.cancelRecording()
        }
        removeResultCard()
        bubbleContainer?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {
            }
        }
        bubbleContainer = null
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun showBubbleOverlay() {
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val containerSize = dp(72)
        val circleSize = dp(56)

        val root = FrameLayout(this)

        val pulseRing = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(containerSize, containerSize, Gravity.CENTER)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#44EF4444"))
            }
            visibility = View.INVISIBLE
        }

        val circle = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(circleSize, circleSize, Gravity.CENTER)
            elevation = dp(8).toFloat()
            background = createCircleBackground("#6366F1", "#818CF8")
        }

        val icon = ImageView(this).apply {
            layoutParams = FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER)
            setImageResource(R.drawable.ic_overlay_mic)
        }

        val spinner = ProgressBar(this).apply {
            layoutParams = FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER)
            isIndeterminate = true
            visibility = View.GONE
        }

        circle.addView(icon)
        circle.addView(spinner)
        root.addView(pulseRing)
        root.addView(circle)

        val screenWidth = resources.displayMetrics.widthPixels
        val params = WindowManager.LayoutParams(
            containerSize,
            containerSize,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = screenWidth - containerSize - dp(12)
            y = dp(220)
        }

        setupBubbleTouch(root, params)

        windowManager.addView(root, params)
        bubbleContainer = root
        bubbleCircle = circle
        pulseRingView = pulseRing
        bubbleIcon = icon
        bubbleSpinner = spinner
        bubbleParams = params
        renderBubbleState(BubbleState.IDLE)
    }

    private fun createCircleBackground(fillHex: String, strokeHex: String): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor(fillHex))
            setStroke(dp(2), Color.parseColor(strokeHex))
        }
    }

    private fun setupBubbleTouch(view: View, params: WindowManager.LayoutParams) {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        view.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                        isDragging = true
                    }
                    if (isDragging) {
                        params.x = initialX + dx
                        params.y = initialY + dy
                        try {
                            windowManager.updateViewLayout(view, params)
                        } catch (_: Exception) {
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        onBubbleTapped()
                    } else {
                        snapToNearestEdge(view, params)
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun snapToNearestEdge(view: View, params: WindowManager.LayoutParams) {
        val screenWidth = resources.displayMetrics.widthPixels
        val screenHeight = resources.displayMetrics.heightPixels
        val targetX = if (params.x + view.width / 2 < screenWidth / 2) {
            dp(8)
        } else {
            screenWidth - view.width - dp(8)
        }
        val clampedY = params.y.coerceIn(dp(48), screenHeight - view.height - dp(72))

        val animator = ValueAnimator.ofInt(params.x, targetX).apply {
            duration = 200L
            addUpdateListener { anim ->
                params.x = anim.animatedValue as Int
                params.y = clampedY
                try {
                    windowManager.updateViewLayout(view, params)
                } catch (_: Exception) {
                }
            }
        }
        animator.start()
    }

    private fun onBubbleTapped() {
        when (bubbleState) {
            BubbleState.IDLE, BubbleState.COPIED -> startOverlayDictation()
            BubbleState.RECORDING -> stopAndFormatOverlayDictation()
            BubbleState.FORMATTING -> Unit
        }
    }

    private fun startOverlayDictation() {
        removeResultCard()
        val startResult = audioEngine.startRecording()
        if (startResult.isFailure) {
            val msg = startResult.exceptionOrNull()?.localizedMessage ?: "Microphone permission required"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
            renderBubbleState(BubbleState.IDLE)
            return
        }
        renderBubbleState(BubbleState.RECORDING)
    }

    private fun stopAndFormatOverlayDictation() {
        renderBubbleState(BubbleState.FORMATTING)
        serviceScope.launch {
            val recorded = audioEngine.stopRecording()
            if (recorded == null) {
                Toast.makeText(this@FloatingOverlayService, "No speech detected.", Toast.LENGTH_SHORT).show()
                renderBubbleState(BubbleState.IDLE)
                return@launch
            }

            val currentSettings = settingsStore.getCurrentSettings()
            val words = withContext(Dispatchers.IO) { repository.getDictionaryWordsSnapshot() }
            val snippets = withContext(Dispatchers.IO) { repository.getSnippetsSnapshot() }

            val aiResult = geminiService.transcribeAndFormatAudio(
                audioWavBytes = recorded.wavBytes,
                toneMode = currentSettings.selectedToneMode,
                dictionaryWords = words,
                snippets = snippets,
                removeFillers = currentSettings.removeFillersEnabled,
                smartCorrections = currentSettings.smartCorrectionsEnabled
            )

            aiResult.onSuccess { result ->
                withContext(Dispatchers.IO) {
                    repository.saveTranscript(
                        TranscriptEntity(
                            title = result.title,
                            rawTranscript = result.rawTranscript,
                            formattedText = result.formattedText,
                            toneModeId = currentSettings.selectedToneMode.id,
                            durationSeconds = recorded.durationSeconds
                        )
                    )
                }

                ClipboardHelper.copyText(this@FloatingOverlayService, result.formattedText)
                renderBubbleState(BubbleState.COPIED)
                showResultCard(result.formattedText, currentSettings.selectedToneMode.shortLabel)

                delay(2200L)
                if (bubbleState == BubbleState.COPIED) {
                    renderBubbleState(BubbleState.IDLE)
                }
            }.onFailure { err ->
                Toast.makeText(
                    this@FloatingOverlayService,
                    err.localizedMessage ?: "Formatting failed.",
                    Toast.LENGTH_LONG
                ).show()
                renderBubbleState(BubbleState.IDLE)
            }
        }
    }

    private fun renderBubbleState(state: BubbleState) {
        bubbleState = state
        val circle = bubbleCircle ?: return
        val icon = bubbleIcon ?: return
        val spinner = bubbleSpinner ?: return
        val ring = pulseRingView ?: return

        pulseAnimator?.cancel()
        ring.visibility = View.INVISIBLE
        ring.scaleX = 1f
        ring.scaleY = 1f
        ring.alpha = 1f

        when (state) {
            BubbleState.IDLE -> {
                circle.background = createCircleBackground("#6366F1", "#818CF8")
                icon.setImageResource(R.drawable.ic_overlay_mic)
                icon.visibility = View.VISIBLE
                spinner.visibility = View.GONE
            }
            BubbleState.RECORDING -> {
                circle.background = createCircleBackground("#EF4444", "#FCA5A5")
                icon.setImageResource(R.drawable.ic_overlay_stop)
                icon.visibility = View.VISIBLE
                spinner.visibility = View.GONE
                ring.visibility = View.VISIBLE
                pulseAnimator = ObjectAnimator.ofFloat(ring, View.ALPHA, 0.9f, 0.25f).apply {
                    duration = 700L
                    repeatMode = ValueAnimator.REVERSE
                    repeatCount = ValueAnimator.INFINITE
                    start()
                }
            }
            BubbleState.FORMATTING -> {
                circle.background = createCircleBackground("#1E2244", "#6366F1")
                icon.visibility = View.GONE
                spinner.visibility = View.VISIBLE
            }
            BubbleState.COPIED -> {
                circle.background = createCircleBackground("#0F2D24", "#10B981")
                icon.setImageResource(R.drawable.ic_overlay_check)
                icon.visibility = View.VISIBLE
                spinner.visibility = View.GONE
            }
        }
    }

    private fun showResultCard(formattedText: String, toneLabel: String) {
        removeResultCard()
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            elevation = dp(12).toFloat()
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(Color.parseColor("#F2161920"))
                setStroke(dp(1), Color.parseColor("#6366F1"))
            }
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val badge = TextView(this).apply {
            text = "COPIED · $toneLabel"
            setTextColor(Color.parseColor("#10B981"))
            textSize = 11f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val shareBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_overlay_share)
            setPadding(dp(6), dp(6), dp(6), dp(6))
            contentDescription = "Share dictation"
            setOnClickListener {
                ClipboardHelper.shareText(this@FloatingOverlayService, formattedText)
                removeResultCard()
            }
        }

        val closeBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_overlay_close)
            setPadding(dp(6), dp(6), dp(6), dp(6))
            contentDescription = "Dismiss preview"
            setOnClickListener {
                removeResultCard()
            }
        }

        headerRow.addView(badge)
        headerRow.addView(shareBtn)
        headerRow.addView(closeBtn)

        val preview = TextView(this).apply {
            text = formattedText
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 4
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(6), 0, dp(8))
        }

        val footerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val pasteHint = TextView(this).apply {
            text = "Ready to paste into any app"
            setTextColor(Color.parseColor("#9CA3AF"))
            textSize = 12f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val copyAgainBtn = TextView(this).apply {
            text = "Copy"
            setTextColor(Color.parseColor("#818CF8"))
            textSize = 12f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener {
                ClipboardHelper.copyText(this@FloatingOverlayService, formattedText)
                Toast.makeText(this@FloatingOverlayService, "Copied to clipboard", Toast.LENGTH_SHORT).show()
            }
        }

        val stopBubbleBtn = TextView(this).apply {
            text = "Hide Bubble"
            setTextColor(Color.parseColor("#9CA3AF"))
            textSize = 12f
            setPadding(dp(8), dp(4), dp(4), dp(4))
            setOnClickListener {
                stopSelf()
            }
        }

        footerRow.addView(pasteHint)
        footerRow.addView(copyAgainBtn)
        footerRow.addView(stopBubbleBtn)

        card.addView(headerRow)
        card.addView(preview)
        card.addView(footerRow)

        val screenWidth = resources.displayMetrics.widthPixels
        val cardWidth = (screenWidth - dp(32)).coerceAtMost(dp(340))
        val params = WindowManager.LayoutParams(
            cardWidth,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(72)
        }

        windowManager.addView(card, params)
        resultCardContainer = card

        autoHideResultJob = serviceScope.launch {
            delay(8500L)
            removeResultCard()
        }
    }

    private fun removeResultCard() {
        autoHideResultJob?.cancel()
        autoHideResultJob = null
        mainHandler.post {
            resultCardContainer?.let {
                try {
                    windowManager.removeView(it)
                } catch (_: Exception) {
                }
            }
            resultCardContainer = null
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.overlay_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.overlay_notif_body)
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openAppIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopServiceIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, FloatingOverlayService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_overlay_mic)
            .setContentTitle(getString(R.string.overlay_notif_title))
            .setContentText(getString(R.string.overlay_notif_body))
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .addAction(
                R.drawable.ic_overlay_close,
                getString(R.string.overlay_stop_action),
                stopServiceIntent
            )
            .build()
    }
}
