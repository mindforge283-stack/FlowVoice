package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoFixHigh
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.BubbleChart
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.DictionaryWordEntity
import com.example.data.local.SnippetEntity
import com.example.data.local.UserSettings
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.ElectricIndigoBright
import com.example.ui.theme.ElectricIndigoContainer
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.MutedSlateText
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RecordingCoral
import com.example.ui.theme.SoftSlateText

@Composable
fun DictionarySettingsScreen(
    dictionaryWords: List<DictionaryWordEntity>,
    snippets: List<SnippetEntity>,
    settings: UserSettings,
    hasMicPermission: Boolean,
    hasOverlayPermission: Boolean,
    onAddDictionaryWord: (String, String) -> Unit,
    onDeleteDictionaryWord: (Long) -> Unit,
    onAddSnippet: (String, String) -> Unit,
    onDeleteSnippet: (Long) -> Unit,
    onToggleOverlay: () -> Unit,
    onRequestMicPermission: () -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onSetAutoCopy: (Boolean) -> Unit,
    onSetRemoveFillers: (Boolean) -> Unit,
    onSetSmartCorrections: (Boolean) -> Unit,
    onSetHaptics: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedSection by remember { mutableIntStateOf(0) } // 0=Dictionary, 1=Snippets, 2=Settings

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 700.dp)
                .align(Alignment.TopCenter)
        ) {
            // Header
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Text(
                    text = stringResource(R.string.dict_settings_title),
                    style = MaterialTheme.typography.headlineMedium,
                    color = PureWhite
                )
                Text(
                    text = "Custom spellings, voice shortcuts & floating mic bubble",
                    style = MaterialTheme.typography.bodySmall,
                    color = SoftSlateText
                )
            }

            // 3-Segment Switcher
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = ObsidianSurface,
                border = BorderStroke(1.dp, ObsidianOutline),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                Row(
                    modifier = Modifier.padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    SegmentTabButton(
                        label = stringResource(R.string.tab_dictionary),
                        selected = selectedSection == 0,
                        onClick = { selectedSection = 0 },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("segment_dictionary")
                    )
                    SegmentTabButton(
                        label = stringResource(R.string.tab_snippets),
                        selected = selectedSection == 1,
                        onClick = { selectedSection = 1 },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("segment_snippets")
                    )
                    SegmentTabButton(
                        label = stringResource(R.string.tab_settings),
                        selected = selectedSection == 2,
                        onClick = { selectedSection = 2 },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("segment_settings")
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            when (selectedSection) {
                0 -> DictionarySection(
                    words = dictionaryWords,
                    onAddWord = onAddDictionaryWord,
                    onDeleteWord = onDeleteDictionaryWord,
                    modifier = Modifier.weight(1f)
                )
                1 -> SnippetsSection(
                    snippets = snippets,
                    onAddSnippet = onAddSnippet,
                    onDeleteSnippet = onDeleteSnippet,
                    modifier = Modifier.weight(1f)
                )
                else -> SettingsOverlaySection(
                    settings = settings,
                    hasMicPermission = hasMicPermission,
                    hasOverlayPermission = hasOverlayPermission,
                    onToggleOverlay = onToggleOverlay,
                    onRequestMicPermission = onRequestMicPermission,
                    onRequestOverlayPermission = onRequestOverlayPermission,
                    onSetAutoCopy = onSetAutoCopy,
                    onSetRemoveFillers = onSetRemoveFillers,
                    onSetSmartCorrections = onSetSmartCorrections,
                    onSetHaptics = onSetHaptics,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun SegmentTabButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = if (selected) ElectricIndigo else ObsidianSurface,
        modifier = modifier.minimumInteractiveComponentSize()
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(vertical = 10.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) PureWhite else SoftSlateText
            )
        }
    }
}

@Composable
private fun DictionarySection(
    words: List<DictionaryWordEntity>,
    onAddWord: (String, String) -> Unit,
    onDeleteWord: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var wordInput by remember { mutableStateOf("") }
    var hintInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = ObsidianSurface,
                border = BorderStroke(1.dp, ObsidianOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Add Custom Term or Name",
                        style = MaterialTheme.typography.titleMedium,
                        color = PureWhite
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = wordInput,
                        onValueChange = { wordInput = it },
                        label = { Text("Exact Spelling (e.g. Kubernetes, Aanya)") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = darkFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dict_word_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = hintInput,
                        onValueChange = { hintInput = it },
                        label = { Text("Optional context / sounds like") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = darkFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("dict_hint_input")
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            onAddWord(wordInput, hintInput)
                            wordInput = ""
                            hintInput = ""
                        },
                        enabled = wordInput.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("dict_add_button")
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save to Dictionary")
                    }
                }
            }
        }

        if (words.isEmpty()) {
            item {
                EmptyVocabularyCard(
                    icon = Icons.Rounded.MenuBook,
                    title = stringResource(R.string.dict_empty_title),
                    body = stringResource(R.string.dict_empty_body)
                )
            }
        } else {
            items(words, key = { it.id }) { word ->
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = ObsidianSurface,
                    border = BorderStroke(1.dp, ObsidianOutline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = word.word,
                                style = MaterialTheme.typography.titleSmall,
                                color = PureWhite
                            )
                            if (word.phoneticHint.isNotBlank()) {
                                Text(
                                    text = word.phoneticHint,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SoftSlateText
                                )
                            }
                        }
                        IconButton(onClick = { onDeleteWord(word.id) }) {
                            Icon(
                                imageVector = Icons.Rounded.DeleteOutline,
                                contentDescription = "Remove word",
                                tint = RecordingCoral.copy(alpha = 0.85f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SnippetsSection(
    snippets: List<SnippetEntity>,
    onAddSnippet: (String, String) -> Unit,
    onDeleteSnippet: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var triggerInput by remember { mutableStateOf("") }
    var expansionInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = ObsidianSurface,
                border = BorderStroke(1.dp, ObsidianOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Create Voice Shortcut",
                        style = MaterialTheme.typography.titleMedium,
                        color = PureWhite
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = triggerInput,
                        onValueChange = { triggerInput = it },
                        label = { Text("When I say (e.g. my email)") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = darkFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("snippet_trigger_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = expansionInput,
                        onValueChange = { expansionInput = it },
                        label = { Text("Expand to (e.g. name@company.com)") },
                        minLines = 2,
                        maxLines = 4,
                        shape = RoundedCornerShape(12.dp),
                        colors = darkFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("snippet_expansion_input")
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            onAddSnippet(triggerInput, expansionInput)
                            triggerInput = ""
                            expansionInput = ""
                        },
                        enabled = triggerInput.isNotBlank() && expansionInput.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .minimumInteractiveComponentSize()
                            .testTag("snippet_add_button")
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save Voice Shortcut")
                    }
                }
            }
        }

        if (snippets.isEmpty()) {
            item {
                EmptyVocabularyCard(
                    icon = Icons.Rounded.Bolt,
                    title = stringResource(R.string.snippets_empty_title),
                    body = stringResource(R.string.snippets_empty_body)
                )
            }
        } else {
            items(snippets, key = { it.id }) { snippet ->
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = ObsidianSurface,
                    border = BorderStroke(1.dp, ObsidianOutline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = ElectricIndigoContainer
                            ) {
                                Text(
                                    text = "\"${snippet.triggerPhrase}\"",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ElectricIndigoBright,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = snippet.expansionText,
                                style = MaterialTheme.typography.bodyMedium,
                                color = PureWhite
                            )
                        }
                        IconButton(onClick = { onDeleteSnippet(snippet.id) }) {
                            Icon(
                                imageVector = Icons.Rounded.DeleteOutline,
                                contentDescription = "Delete snippet",
                                tint = RecordingCoral.copy(alpha = 0.85f)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsOverlaySection(
    settings: UserSettings,
    hasMicPermission: Boolean,
    hasOverlayPermission: Boolean,
    onToggleOverlay: () -> Unit,
    onRequestMicPermission: () -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onSetAutoCopy: (Boolean) -> Unit,
    onSetRemoveFillers: (Boolean) -> Unit,
    onSetSmartCorrections: (Boolean) -> Unit,
    onSetHaptics: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = ObsidianSurface,
                border = BorderStroke(
                    1.dp,
                    if (settings.overlayRunning) ElectricIndigo else ObsidianOutline
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = ElectricIndigoContainer
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.BubbleChart,
                                contentDescription = null,
                                tint = ElectricIndigoBright,
                                modifier = Modifier
                                    .padding(10.dp)
                                    .size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Floating Mic Bubble",
                                style = MaterialTheme.typography.titleMedium,
                                color = PureWhite
                            )
                            Text(
                                text = "Dictate inside WhatsApp, Gmail & Notes",
                                style = MaterialTheme.typography.bodySmall,
                                color = SoftSlateText
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    PermissionStatusRow(
                        label = "Microphone Access",
                        granted = hasMicPermission,
                        actionLabel = "Grant",
                        onAction = onRequestMicPermission
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    PermissionStatusRow(
                        label = "Display Over Other Apps",
                        granted = hasOverlayPermission,
                        actionLabel = "Enable",
                        onAction = onRequestOverlayPermission
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    if (settings.overlayRunning) {
                        OutlinedButton(
                            onClick = onToggleOverlay,
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, RecordingCoral.copy(alpha = 0.7f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("settings_overlay_button")
                        ) {
                            Text("Turn Off Floating Bubble", color = RecordingCoral)
                        }
                    } else {
                        Button(
                            onClick = onToggleOverlay,
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .minimumInteractiveComponentSize()
                                .testTag("settings_overlay_button")
                        ) {
                            Text("Launch Floating Mic Bubble", color = PureWhite)
                        }
                    }
                }
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = ObsidianSurface,
                border = BorderStroke(1.dp, ObsidianOutline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.AutoFixHigh,
                            contentDescription = null,
                            tint = ElectricIndigoBright
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "AI Formatting & Clipboard",
                            style = MaterialTheme.typography.titleMedium,
                            color = PureWhite
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    SettingSwitchRow(
                        title = "Auto-copy to clipboard",
                        subtitle = "Automatically copy cleaned text after dictation",
                        checked = settings.autoCopyEnabled,
                        onCheckedChange = onSetAutoCopy
                    )
                    SettingSwitchRow(
                        title = "Remove filler words",
                        subtitle = "Strip \"um\", \"uh\", \"like\", and false starts",
                        checked = settings.removeFillersEnabled,
                        onCheckedChange = onSetRemoveFillers
                    )
                    SettingSwitchRow(
                        title = "Smart self-corrections",
                        subtitle = "Resolve edits like \"at 5, actually make it 6\"",
                        checked = settings.smartCorrectionsEnabled,
                        onCheckedChange = onSetSmartCorrections
                    )
                    SettingSwitchRow(
                        title = "Haptic feedback",
                        subtitle = "Tactile pulse on press and hands-free lock",
                        checked = settings.hapticsEnabled,
                        onCheckedChange = onSetHaptics
                    )
                }
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = EmeraldContainer.copy(alpha = 0.65f),
                border = BorderStroke(1.dp, EmeraldSuccess.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "FlowVoice is 100% free with no paywalls or subscriptions. Transcripts and personal vocabulary stay stored locally on your device.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SoftSlateText,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(14.dp)
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun PermissionStatusRow(
    label: String,
    granted: Boolean,
    actionLabel: String,
    onAction: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = ObsidianSurfaceElevated,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (granted) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (granted) EmeraldSuccess else MutedSlateText,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = PureWhite,
                modifier = Modifier.weight(1f)
            )
            if (granted) {
                Text(
                    text = "Granted",
                    style = MaterialTheme.typography.labelSmall,
                    color = EmeraldSuccess
                )
            } else {
                Surface(
                    onClick = onAction,
                    shape = RoundedCornerShape(8.dp),
                    color = ElectricIndigoContainer
                ) {
                    Text(
                        text = actionLabel,
                        style = MaterialTheme.typography.labelMedium,
                        color = ElectricIndigoBright,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = PureWhite
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = SoftSlateText
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = PureWhite,
                checkedTrackColor = ElectricIndigo,
                uncheckedThumbColor = SoftSlateText,
                uncheckedTrackColor = ObsidianSurfaceElevated,
                uncheckedBorderColor = ObsidianOutline
            )
        )
    }
}

@Composable
private fun EmptyVocabularyCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    body: String
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = ObsidianSurface,
        border = BorderStroke(1.dp, ObsidianOutline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = ElectricIndigoBright,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = PureWhite,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = body,
                style = MaterialTheme.typography.bodySmall,
                color = SoftSlateText,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun darkFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedContainerColor = ObsidianSurfaceElevated,
    unfocusedContainerColor = ObsidianSurfaceElevated,
    focusedBorderColor = ElectricIndigo,
    unfocusedBorderColor = ObsidianOutline,
    focusedTextColor = PureWhite,
    unfocusedTextColor = PureWhite,
    focusedLabelColor = ElectricIndigoBright,
    unfocusedLabelColor = SoftSlateText,
    cursorColor = ElectricIndigoBright
)
