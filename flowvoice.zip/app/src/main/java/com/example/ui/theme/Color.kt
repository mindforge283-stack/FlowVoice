package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBackground = Color(0xFF0F1115)
val ObsidianSurface = Color(0xFF161920)
val ObsidianSurfaceElevated = Color(0xFF1D222C)
val ObsidianSurfaceHighest = Color(0xFF252B38)
val ObsidianOutline = Color(0xFF2E3545)
val ObsidianOutlineSubtle = Color(0xFF222733)

val ElectricIndigo = Color(0xFF6366F1)
val ElectricIndigoBright = Color(0xFF818CF8)
val ElectricIndigoDeep = Color(0xFF4F46E5)
val ElectricIndigoContainer = Color(0xFF1E2244)

val PureWhite = Color(0xFFFFFFFF)
val SoftSlateText = Color(0xFF9CA3AF)
val MutedSlateText = Color(0xFF6B7280)

val EmeraldSuccess = Color(0xFF10B981)
val EmeraldContainer = Color(0xFF0F2D24)
val RecordingCoral = Color(0xFFEF4444)
val RecordingCoralContainer = Color(0xFF3A181B)
val AmberWarning = Color(0xFFF59E0B)
