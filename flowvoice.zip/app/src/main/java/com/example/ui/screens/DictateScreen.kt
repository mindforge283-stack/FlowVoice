package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BubbleChart
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.UserSettings
import com.example.data.model.ToneMode
import com.example.ui.components.LiveWaveformCanvas
import com.example.ui.components.MicrophoneOrbButton
import com.example.ui.components.RecordingStatusPill
import com.example.ui.components.ToneSelectorBar
import com.example.ui.components.toneIcon
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.ElectricIndigoBright
import com.example.ui.theme.ElectricIndigoContainer
import com.example.ui.theme.EmeraldContainer
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.MutedSlateText
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RecordingCoral
import com.example.ui.theme.RecordingCoralContainer
import com.example.ui.theme.SoftSlateText
import com.example.ui.viewmodel.DictationStage
import com.example.util.ClipboardHelper

@Composable
fun DictateScreen(
    stage: DictationStage,
    settings: UserSettings,
    waveform: List<Float>,
    currentAmplitude: Float,
    elapsedSeconds: Int,
    dictionaryCount: Int,
    snippetCount: Int,
    hasMicPermission: Boolean,
    onRequestMicPermission: () -> Unit,
    onStartRecording: () -> Boolean,
    onDragLockRecording: () -> Unit,
    onQuickTapLockRecording: () -> Unit,
    onStopAndFormat: () -> Unit,
    onCancelRecording: () -> Unit,
    onSelectToneMode: (ToneMode) -> Unit,
    onFormatManualText: (String) -> Unit,
    onCopyText: (String) -> Unit,
    onResetStage: () -> Unit,
    onToggleOverlay: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showTypeDialog by remember { mutableStateOf(false) }
    var showRawText by remember(stage) { mutableStateOf(false) }

    val isRecording = stage is DictationStage.Recording
    val isLocked = (stage as? DictationStage.Recording)?.isLocked == true
    val isFormatting = stage is DictationStage.Formatting

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
    ) {
        // Subtle atmospheric acoustic banner backdrop at top
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_acoustic_banner),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .alpha(0.28f)
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                ObsidianBackground.copy(alpha = 0.25f),
                                ObsidianBackground.copy(alpha = 0.85f),
                                ObsidianBackground
                            )
                        )
                    )
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 640.dp)
                .align(Alignment.TopCenter),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top App Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = ElectricIndigoContainer,
                        border = BorderStroke(1.dp, ElectricIndigo.copy(alpha = 0.5f))
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.GraphicEq,
                            contentDescription = null,
                            tint = ElectricIndigoBright,
                            modifier = Modifier
                                .padding(8.dp)
                                .size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = stringResource(R.string.app_name),
                            style = MaterialTheme.typography.titleLarge,
                            color = PureWhite
                        )
                        Text(
                            text = stringResource(R.string.dictate_subtitle),
                            style = MaterialTheme.typography.bodySmall,
                            color = SoftSlateText
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = { showTypeDialog = true },
                        enabled = !isRecording && !isFormatting,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("manual_text_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.EditNote,
                            contentDescription = stringResource(R.string.dictate_type_instead),
                            tint = SoftSlateText
                        )
                    }

                    Surface(
                        onClick = onToggleOverlay,
                        shape = RoundedCornerShape(20.dp),
                        color = if (settings.overlayRunning) ElectricIndigoContainer else ObsidianSurfaceElevated,
                        border = BorderStroke(
                            1.dp,
                            if (settings.overlayRunning) ElectricIndigo else ObsidianOutline
                        ),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("header_overlay_toggle")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.BubbleChart,
                                contentDescription = null,
                                tint = if (settings.overlayRunning) ElectricIndigoBright else SoftSlateText,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (settings.overlayRunning) {
                                    stringResource(R.string.dictate_bubble_on)
                                } else {
                                    stringResource(R.string.dictate_bubble_off)
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = if (settings.overlayRunning) PureWhite else SoftSlateText
                            )
                        }
                    }
                }
            }

            // Tone & Style Quick Selector Bar (works before or after recording)
            ToneSelectorBar(
                selectedTone = settings.selectedToneMode,
                onToneSelected = onSelectToneMode,
                enabled = !isRecording && !isFormatting
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Middle Interactive Stage
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.Center
            ) {
                AnimatedContent(
                    targetState = stage,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "dictationStage"
                ) { currentStage ->
                    when (currentStage) {
                        is DictationStage.Idle -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = ObsidianSurface.copy(alpha = 0.85f),
                                    border = BorderStroke(1.dp, ObsidianOutlineSubtleOrDefault)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 18.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Icon(
                                            imageVector = toneIcon(settings.selectedToneMode),
                                            contentDescription = null,
                                            tint = ElectricIndigoBright,
                                            modifier = Modifier.size(26.dp)
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "Ready in ${settings.selectedToneMode.label} mode",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = PureWhite,
                                            textAlign = TextAlign.Center
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = settings.selectedToneMode.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = SoftSlateText,
                                            textAlign = TextAlign.Center
                                        )
                                        if (dictionaryCount > 0 || snippetCount > 0) {
                                            Spacer(modifier = Modifier.height(10.dp))
                                            Text(
                                                text = "$dictionaryCount custom words · $snippetCount voice shortcuts active",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = ElectricIndigoBright
                                            )
                                        }
                                    }
                                }

                                if (!hasMicPermission) {
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Surface(
                                        onClick = onRequestMicPermission,
                                        shape = RoundedCornerShape(16.dp),
                                        color = ElectricIndigoContainer,
                                        border = BorderStroke(1.dp, ElectricIndigo),
                                        modifier = Modifier.testTag("grant_mic_banner")
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "Tap to grant Microphone permission before recording",
                                                style = MaterialTheme.typography.labelLarge,
                                                color = PureWhite
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        is DictationStage.Recording -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                RecordingStatusPill(
                                    elapsedSeconds = elapsedSeconds,
                                    isLocked = currentStage.isLocked
                                )
                                Spacer(modifier = Modifier.height(24.dp))
                                LiveWaveformCanvas(
                                    waveform = waveform,
                                    isRecording = true,
                                    isFormatting = false
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = if (currentStage.isLocked) {
                                        "Listening hands-free…"
                                    } else {
                                        "Listening… release when finished"
                                    },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = SoftSlateText
                                )
                            }
                        }

                        is DictationStage.Formatting -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = ObsidianSurfaceElevated,
                                    border = BorderStroke(1.dp, ElectricIndigo.copy(alpha = 0.5f))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(24.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        LiveWaveformCanvas(
                                            waveform = waveform,
                                            isRecording = false,
                                            isFormatting = true
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))
                                        Text(
                                            text = currentStage.statusLabel,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = PureWhite
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = stringResource(R.string.dictate_formatting_subtitle),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = SoftSlateText,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }

                        is DictationStage.Result -> {
                            val transcript = currentStage.transcript
                            val activeTone = ToneMode.fromId(transcript.toneModeId)

                            Surface(
                                shape = RoundedCornerShape(22.dp),
                                color = ObsidianSurface,
                                border = BorderStroke(1.dp, ObsidianOutline),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("dictation_result_card")
                            ) {
                                Column(
                                    modifier = Modifier
                                        .padding(18.dp)
                                        .verticalScroll(rememberScrollState())
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(
                                                shape = RoundedCornerShape(10.dp),
                                                color = ElectricIndigoContainer
                                            ) {
                                                Text(
                                                    text = activeTone.label,
                                                    style = MaterialTheme.typography.labelMedium,
                                                    color = ElectricIndigoBright,
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                                )
                                            }
                                            if (currentStage.wasAutoCopied) {
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Surface(
                                                    shape = RoundedCornerShape(10.dp),
                                                    color = EmeraldContainer
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Rounded.CheckCircle,
                                                            contentDescription = null,
                                                            tint = EmeraldSuccess,
                                                            modifier = Modifier.size(13.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text(
                                                            text = "Copied",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = EmeraldSuccess
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        if (transcript.rawTranscript.isNotBlank() &&
                                            transcript.rawTranscript != transcript.formattedText
                                        ) {
                                            Surface(
                                                onClick = { showRawText = !showRawText },
                                                shape = RoundedCornerShape(10.dp),
                                                color = ObsidianSurfaceElevated,
                                                modifier = Modifier.testTag("toggle_raw_button")
                                            ) {
                                                Text(
                                                    text = if (showRawText) {
                                                        stringResource(R.string.dictate_formatted_toggle)
                                                    } else {
                                                        stringResource(R.string.dictate_raw_toggle)
                                                    },
                                                    style = MaterialTheme.typography.labelMedium,
                                                    color = SoftSlateText,
                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    Text(
                                        text = if (showRawText) transcript.rawTranscript else transcript.formattedText,
                                        style = MaterialTheme.typography.bodyLarge.copy(
                                            fontWeight = FontWeight.Normal
                                        ),
                                        color = PureWhite
                                    )

                                    Spacer(modifier = Modifier.height(16.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Button(
                                            onClick = { onCopyText(transcript.formattedText) },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = ElectricIndigo,
                                                contentColor = PureWhite
                                            ),
                                            shape = RoundedCornerShape(14.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .minimumInteractiveComponentSize()
                                                .testTag("result_copy_button")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.ContentCopy,
                                                contentDescription = null,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(stringResource(R.string.dictate_copy))
                                        }

                                        FilledTonalButton(
                                            onClick = {
                                                ClipboardHelper.shareText(context, transcript.formattedText)
                                            },
                                            colors = ButtonDefaults.filledTonalButtonColors(
                                                containerColor = ObsidianSurfaceElevated,
                                                contentColor = PureWhite
                                            ),
                                            shape = RoundedCornerShape(14.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .minimumInteractiveComponentSize()
                                                .testTag("result_share_button")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Share,
                                                contentDescription = null,
                                                tint = ElectricIndigoBright,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(stringResource(R.string.dictate_share))
                                        }

                                        IconButton(
                                            onClick = onResetStage,
                                            modifier = Modifier
                                                .clip(CircleShape)
                                                .background(ObsidianSurfaceElevated)
                                                .minimumInteractiveComponentSize()
                                                .testTag("result_clear_button")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Rounded.Close,
                                                contentDescription = "Clear result",
                                                tint = SoftSlateText
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Tip: Tap any tone pill above to re-format this note instantly.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MutedSlateText
                                    )
                                }
                            }
                        }

                        is DictationStage.Error -> {
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = RecordingCoralContainer,
                                border = BorderStroke(1.dp, RecordingCoral.copy(alpha = 0.6f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("dictation_error_card")
                            ) {
                                Column(
                                    modifier = Modifier.padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.ErrorOutline,
                                        contentDescription = null,
                                        tint = RecordingCoral,
                                        modifier = Modifier.size(30.dp)
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Text(
                                        text = currentStage.message,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = PureWhite,
                                        textAlign = TextAlign.Center
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    TextButton(onClick = onResetStage) {
                                        Icon(
                                            imageVector = Icons.Rounded.Refresh,
                                            contentDescription = null,
                                            tint = PureWhite,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Dismiss", color = PureWhite)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Tactile Microphone Orb & Controls
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Left Cancel button when locked
                    AnimatedVisibility(visible = isRecording && isLocked) {
                        OutlinedButton(
                            onClick = onCancelRecording,
                            shape = RoundedCornerShape(18.dp),
                            border = BorderStroke(1.dp, ObsidianOutline),
                            modifier = Modifier
                                .padding(end = 16.dp)
                                .minimumInteractiveComponentSize()
                                .testTag("cancel_recording_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = stringResource(R.string.dictate_cancel),
                                tint = SoftSlateText,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(stringResource(R.string.dictate_cancel), color = SoftSlateText)
                        }
                    }

                    MicrophoneOrbButton(
                        isRecording = isRecording,
                        isLocked = isLocked,
                        isFormatting = isFormatting,
                        currentAmplitude = currentAmplitude,
                        hapticsEnabled = settings.hapticsEnabled,
                        onPressStart = {
                            if (!hasMicPermission) {
                                onRequestMicPermission()
                                false
                            } else {
                                onStartRecording()
                            }
                        },
                        onDragLock = onDragLockRecording,
                        onQuickTapLock = onQuickTapLockRecording,
                        onReleaseFinish = onStopAndFormat,
                        onStopLockedClick = onStopAndFormat
                    )

                    // Right Stop & Format button when locked
                    AnimatedVisibility(visible = isRecording && isLocked) {
                        Button(
                            onClick = onStopAndFormat,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ElectricIndigo,
                                contentColor = PureWhite
                            ),
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier
                                .padding(start = 16.dp)
                                .minimumInteractiveComponentSize()
                                .testTag("stop_locked_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Stop,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Format")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = when {
                        isFormatting -> stringResource(R.string.dictate_formatting_title)
                        isRecording && isLocked -> stringResource(R.string.dictate_hint_locked)
                        isRecording -> stringResource(R.string.dictate_hint_holding)
                        else -> stringResource(R.string.dictate_hint_idle)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = SoftSlateText,
                    textAlign = TextAlign.Center
                )
            }
        }
    }

    if (showTypeDialog) {
        ManualTextCleanupDialog(
            selectedTone = settings.selectedToneMode,
            onDismiss = { showTypeDialog = false },
            onSubmit = { text ->
                showTypeDialog = false
                onFormatManualText(text)
            }
        )
    }
}

private val ObsidianOutlineSubtleOrDefault: Color
    get() = ObsidianOutline.copy(alpha = 0.7f)

@Composable
private fun ManualTextCleanupDialog(
    selectedTone: ToneMode,
    onDismiss: () -> Unit,
    onSubmit: (String) -> Unit
) {
    var draftText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ObsidianSurface,
        titleContentColor = PureWhite,
        textContentColor = SoftSlateText,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.AutoAwesome,
                    contentDescription = null,
                    tint = ElectricIndigoBright
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text("AI Text Cleanup")
            }
        },
        text = {
            Column {
                Text(
                    text = "Paste or type rough notes (with fillers or corrections) to format in ${selectedTone.label} mode.",
                    style = MaterialTheme.typography.bodySmall,
                    color = SoftSlateText
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = draftText,
                    onValueChange = { draftText = it },
                    placeholder = {
                        Text(
                            "e.g. Um hey team let's meet at 5 actually make it 6 to review my email",
                            color = MutedSlateText
                        )
                    },
                    minLines = 4,
                    maxLines = 7,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricIndigo,
                        unfocusedBorderColor = ObsidianOutline,
                        focusedTextColor = PureWhite,
                        unfocusedTextColor = PureWhite,
                        cursorColor = ElectricIndigoBright
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("manual_text_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(draftText) },
                enabled = draftText.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo)
            ) {
                Text("Format with Gemini")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = SoftSlateText)
            }
        }
    )
}
