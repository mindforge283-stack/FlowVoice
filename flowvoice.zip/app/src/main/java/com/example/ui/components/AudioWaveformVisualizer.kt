package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.ElectricIndigoBright
import com.example.ui.theme.ElectricIndigoDeep
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RecordingCoral
import com.example.ui.theme.SoftSlateText
import kotlin.math.roundToInt

@Composable
fun LiveWaveformCanvas(
    waveform: List<Float>,
    isRecording: Boolean,
    isFormatting: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveformIdle")
    val idleBreath by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.6f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "idleBreath"
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(68.dp)
    ) {
        val barCount = waveform.size.coerceAtLeast(1)
        val totalWidth = size.width
        val slotWidth = totalWidth / barCount
        val barWidth = (slotWidth * 0.56f).coerceIn(4f, 14f)
        val centerY = size.height / 2f
        val maxHeight = size.height * 0.92f

        for (index in 0 until barCount) {
            val rawAmp = waveform[index]
            val amplitude = when {
                isRecording -> rawAmp.coerceIn(0.08f, 1f)
                isFormatting -> {
                    val wave = kotlin.math.sin((index * 0.45f) + idleBreath * 6f) * 0.25f + 0.38f
                    wave.coerceIn(0.14f, 0.7f)
                }
                else -> 0.10f
            }

            val barHeight = (maxHeight * amplitude).coerceAtLeast(8f)
            val left = index * slotWidth + (slotWidth - barWidth) / 2f
            val top = centerY - barHeight / 2f

            val brush = if (isRecording) {
                Brush.verticalGradient(
                    colors = listOf(ElectricIndigoBright, ElectricIndigo, RecordingCoral.copy(alpha = 0.85f))
                )
            } else if (isFormatting) {
                Brush.verticalGradient(
                    colors = listOf(ElectricIndigoBright, ElectricIndigo)
                )
            } else {
                Brush.verticalGradient(
                    colors = listOf(ObsidianOutline, ObsidianOutline)
                )
            }

            drawRoundRect(
                brush = brush,
                topLeft = Offset(left, top),
                size = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            )
        }
    }
}

@Composable
fun MicrophoneOrbButton(
    isRecording: Boolean,
    isLocked: Boolean,
    isFormatting: Boolean,
    currentAmplitude: Float,
    hapticsEnabled: Boolean,
    onPressStart: () -> Boolean,
    onDragLock: () -> Unit,
    onQuickTapLock: () -> Unit,
    onReleaseFinish: () -> Unit,
    onStopLockedClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current
    val lockThresholdPx = with(density) { 64.dp.toPx() }
    var dragOffsetY by remember { mutableFloatStateOf(0f) }

    val infiniteTransition = rememberInfiniteTransition(label = "micPulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.32f,
        animationSpec = infiniteRepeatable(
            animation = tween(950, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.48f,
        targetValue = 0.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(950, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    val voiceScale by animateFloatAsState(
        targetValue = if (isRecording) 1f + (currentAmplitude * 0.14f) else 1f,
        animationSpec = spring(stiffness = 400f),
        label = "voiceScale"
    )

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Slide-up-to-lock indicator shown while holding before lock
        Box(
            modifier = Modifier.height(44.dp),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.animation.AnimatedVisibility(
                visible = isRecording && !isLocked,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut()
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = ObsidianSurfaceElevated,
                    border = androidx.compose.foundation.BorderStroke(1.dp, ElectricIndigo.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Lock,
                            contentDescription = null,
                            tint = ElectricIndigoBright,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Slide up to lock",
                            style = MaterialTheme.typography.labelMedium,
                            color = PureWhite
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(152.dp)
        ) {
            // Outer ambient pulsing halo when listening
            if (isRecording) {
                Box(
                    modifier = Modifier
                        .size(126.dp)
                        .scale(pulseScale + currentAmplitude * 0.18f)
                        .clip(CircleShape)
                        .background(
                            (if (isLocked) ElectricIndigo else RecordingCoral).copy(alpha = pulseAlpha)
                        )
                )
            } else if (!isFormatting) {
                Box(
                    modifier = Modifier
                        .size(116.dp)
                        .clip(CircleShape)
                        .border(1.dp, ElectricIndigo.copy(alpha = 0.25f), CircleShape)
                )
            }

            val orbBrush = when {
                isFormatting -> Brush.linearGradient(listOf(ObsidianSurfaceElevated, ObsidianSurfaceElevated))
                isRecording && isLocked -> Brush.linearGradient(listOf(RecordingCoral, Color(0xFFDC2626)))
                isRecording -> Brush.linearGradient(listOf(ElectricIndigoBright, RecordingCoral))
                else -> Brush.linearGradient(listOf(ElectricIndigoBright, ElectricIndigoDeep))
            }

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .offset { IntOffset(0, dragOffsetY.roundToInt()) }
                    .size(96.dp)
                    .scale(voiceScale)
                    .clip(CircleShape)
                    .background(orbBrush)
                    .border(
                        width = 2.dp,
                        color = if (isRecording) PureWhite.copy(alpha = 0.45f) else ElectricIndigoBright.copy(alpha = 0.5f),
                        shape = CircleShape
                    )
                    .testTag("mic_orb_button")
                    .pointerInput(isFormatting, isLocked, isRecording) {
                        if (isFormatting) return@pointerInput

                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            val downTime = System.currentTimeMillis()

                            if (isRecording && isLocked) {
                                // Wait for release to stop locked hands-free recording
                                while (true) {
                                    val event = awaitPointerEvent()
                                    if (event.changes.all { !it.pressed }) {
                                        if (hapticsEnabled) {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        }
                                        onStopLockedClick()
                                        break
                                    }
                                }
                                return@awaitEachGesture
                            }

                            val started = onPressStart()
                            if (!started) {
                                // Drain pointer up if permission dialog triggered
                                while (true) {
                                    val event = awaitPointerEvent()
                                    if (event.changes.all { !it.pressed }) break
                                }
                                return@awaitEachGesture
                            }

                            if (hapticsEnabled) {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            }

                            var lockedByDrag = false
                            var totalDy = 0f

                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.id == down.id } ?: event.changes.first()
                                if (!change.pressed) {
                                    dragOffsetY = 0f
                                    if (!lockedByDrag) {
                                        val heldMs = System.currentTimeMillis() - downTime
                                        if (heldMs < 350L) {
                                            onQuickTapLock()
                                        } else {
                                            onReleaseFinish()
                                        }
                                    }
                                    break
                                } else {
                                    val dy = change.position.y - change.previousPosition.y
                                    totalDy = (totalDy + dy).coerceIn(-lockThresholdPx * 1.25f, 12f)
                                    dragOffsetY = totalDy * 0.45f
                                    if (!lockedByDrag && totalDy <= -lockThresholdPx) {
                                        lockedByDrag = true
                                        dragOffsetY = 0f
                                        if (hapticsEnabled) {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                        }
                                        onDragLock()
                                    }
                                }
                            }
                        }
                    }
            ) {
                when {
                    isFormatting -> {
                        CircularProgressIndicator(
                            color = ElectricIndigoBright,
                            strokeWidth = 3.dp,
                            modifier = Modifier.size(34.dp)
                        )
                    }
                    isRecording && isLocked -> {
                        Icon(
                            imageVector = Icons.Rounded.Stop,
                            contentDescription = "Stop hands-free recording",
                            tint = PureWhite,
                            modifier = Modifier.size(38.dp)
                        )
                    }
                    else -> {
                        Icon(
                            imageVector = Icons.Rounded.Mic,
                            contentDescription = "Hold to talk or tap to lock",
                            tint = PureWhite,
                            modifier = Modifier.size(38.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RecordingStatusPill(
    elapsedSeconds: Int,
    isLocked: Boolean,
    modifier: Modifier = Modifier
) {
    val mins = elapsedSeconds / 60
    val secs = elapsedSeconds % 60
    val formatted = "%02d:%02d".format(mins, secs)

    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        color = ObsidianSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isLocked) ElectricIndigo else RecordingCoral.copy(alpha = 0.7f)
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (isLocked) ElectricIndigoBright else RecordingCoral)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (isLocked) "HANDS-FREE" else "HOLDING",
                style = MaterialTheme.typography.labelSmall,
                color = SoftSlateText
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = formatted,
                style = MaterialTheme.typography.labelSmall,
                color = PureWhite
            )
        }
    }
}
