package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioRecorderEngine
import com.example.data.ai.GeminiDictationService
import com.example.data.local.AppDatabase
import com.example.data.local.DictionaryWordEntity
import com.example.data.local.FlowVoiceRepository
import com.example.data.local.SettingsStore
import com.example.data.local.SnippetEntity
import com.example.data.local.TranscriptEntity
import com.example.data.local.UserSettings
import com.example.data.model.ToneMode
import com.example.overlay.FloatingOverlayService
import com.example.util.ClipboardHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

sealed interface DictationStage {
    data object Idle : DictationStage
    data class Recording(
        val isLocked: Boolean = false
    ) : DictationStage
    data class Formatting(
        val toneMode: ToneMode,
        val statusLabel: String = "Polishing your voice…"
    ) : DictationStage
    data class Result(
        val transcript: TranscriptEntity,
        val wasAutoCopied: Boolean
    ) : DictationStage
    data class Error(val message: String) : DictationStage
}

class FlowVoiceViewModel(application: Application) : AndroidViewModel(application) {
    companion object {
        private const val TAG = "FlowVoiceViewModel"
    }

    private val appContext: Context = application.applicationContext
    private val dao = AppDatabase.getInstance(appContext).flowVoiceDao()
    private val repository = FlowVoiceRepository(dao)
    private val settingsStore = SettingsStore.getInstance(appContext)
    private val geminiService = GeminiDictationService()
    private val audioEngine = AudioRecorderEngine()

    val settings: StateFlow<UserSettings> = settingsStore.settings

    val transcripts: StateFlow<List<TranscriptEntity>> = repository.transcripts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val dictionaryWords: StateFlow<List<DictionaryWordEntity>> = repository.dictionaryWords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val snippets: StateFlow<List<SnippetEntity>> = repository.snippets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val waveform: StateFlow<List<Float>> = audioEngine.waveform
    val currentAmplitude: StateFlow<Float> = audioEngine.currentAmplitude
    val elapsedSeconds: StateFlow<Int> = audioEngine.elapsedSeconds

    private val _dictationStage = MutableStateFlow<DictationStage>(DictationStage.Idle)
    val dictationStage: StateFlow<DictationStage> = _dictationStage.asStateFlow()

    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    private val _reformattingHistoryId = MutableStateFlow<Long?>(null)
    val reformattingHistoryId: StateFlow<Long?> = _reformattingHistoryId.asStateFlow()

    fun consumeSnackbar() {
        _snackbarMessage.value = null
    }

    fun showMessage(message: String) {
        _snackbarMessage.value = message
    }

    fun startRecording(locked: Boolean = false): Boolean {
        val result = audioEngine.startRecording()
        return if (result.isSuccess) {
            _dictationStage.value = DictationStage.Recording(isLocked = locked)
            true
        } else {
            val message = result.exceptionOrNull()?.localizedMessage
                ?: "Unable to start microphone recording."
            _dictationStage.value = DictationStage.Error(message)
            false
        }
    }

    fun lockRecording() {
        val current = _dictationStage.value
        if (current is DictationStage.Recording && !current.isLocked) {
            _dictationStage.value = current.copy(isLocked = true)
        }
    }

    fun cancelRecording() {
        viewModelScope.launch {
            audioEngine.cancelRecording()
            _dictationStage.value = DictationStage.Idle
        }
    }

    fun stopAndFormatRecording() {
        val stage = _dictationStage.value
        if (stage !is DictationStage.Recording) return

        val currentSettings = settings.value
        _dictationStage.value = DictationStage.Formatting(
            toneMode = currentSettings.selectedToneMode,
            statusLabel = "Polishing your voice…"
        )

        viewModelScope.launch {
            val recorded = audioEngine.stopRecording()
            if (recorded == null) {
                _dictationStage.value = DictationStage.Error("No audio was captured. Hold and speak clearly.")
                return@launch
            }

            val words = withContext(Dispatchers.IO) { repository.getDictionaryWordsSnapshot() }
            val activeSnippets = withContext(Dispatchers.IO) { repository.getSnippetsSnapshot() }

            val aiResult = geminiService.transcribeAndFormatAudio(
                audioWavBytes = recorded.wavBytes,
                toneMode = currentSettings.selectedToneMode,
                dictionaryWords = words,
                snippets = activeSnippets,
                removeFillers = currentSettings.removeFillersEnabled,
                smartCorrections = currentSettings.smartCorrectionsEnabled
            )

            aiResult.onSuccess { result ->
                val entity = TranscriptEntity(
                    title = result.title,
                    rawTranscript = result.rawTranscript,
                    formattedText = result.formattedText,
                    toneModeId = currentSettings.selectedToneMode.id,
                    durationSeconds = recorded.durationSeconds
                )
                val insertedId = withContext(Dispatchers.IO) {
                    repository.saveTranscript(entity)
                }
                val saved = entity.copy(id = insertedId)
                val copied = if (currentSettings.autoCopyEnabled) {
                    ClipboardHelper.copyText(appContext, saved.formattedText)
                } else {
                    false
                }
                _dictationStage.value = DictationStage.Result(
                    transcript = saved,
                    wasAutoCopied = copied
                )
            }.onFailure { error ->
                Log.e(TAG, "Dictation formatting failed", error)
                _dictationStage.value = DictationStage.Error(
                    error.localizedMessage ?: "Failed to transcribe audio."
                )
            }
        }
    }

    fun selectToneMode(toneMode: ToneMode) {
        settingsStore.setToneMode(toneMode)
        val stage = _dictationStage.value
        if (stage is DictationStage.Result && stage.transcript.toneModeId != toneMode.id) {
            reformatActiveResult(stage.transcript, toneMode)
        }
    }

    private fun reformatActiveResult(existing: TranscriptEntity, newTone: ToneMode) {
        val currentSettings = settings.value
        val sourceText = existing.rawTranscript.ifBlank { existing.formattedText }
        _dictationStage.value = DictationStage.Formatting(
            toneMode = newTone,
            statusLabel = "Re-formatting as ${newTone.label}…"
        )

        viewModelScope.launch {
            val words = withContext(Dispatchers.IO) { repository.getDictionaryWordsSnapshot() }
            val activeSnippets = withContext(Dispatchers.IO) { repository.getSnippetsSnapshot() }

            val aiResult = geminiService.reformatText(
                sourceText = sourceText,
                toneMode = newTone,
                dictionaryWords = words,
                snippets = activeSnippets,
                removeFillers = currentSettings.removeFillersEnabled,
                smartCorrections = currentSettings.smartCorrectionsEnabled
            )

            aiResult.onSuccess { result ->
                val updated = existing.copy(
                    title = result.title,
                    formattedText = result.formattedText,
                    toneModeId = newTone.id
                )
                withContext(Dispatchers.IO) {
                    repository.updateTranscript(updated)
                }
                val copied = if (currentSettings.autoCopyEnabled) {
                    ClipboardHelper.copyText(appContext, updated.formattedText)
                } else {
                    false
                }
                _dictationStage.value = DictationStage.Result(
                    transcript = updated,
                    wasAutoCopied = copied
                )
            }.onFailure { error ->
                Log.e(TAG, "Reformat failed", error)
                _dictationStage.value = DictationStage.Result(existing, wasAutoCopied = false)
                _snackbarMessage.value = error.localizedMessage ?: "Could not re-format text."
            }
        }
    }

    fun formatManualText(rawText: String) {
        val trimmed = rawText.trim()
        if (trimmed.isEmpty()) return

        val currentSettings = settings.value
        _dictationStage.value = DictationStage.Formatting(
            toneMode = currentSettings.selectedToneMode,
            statusLabel = "Formatting text with Gemini…"
        )

        viewModelScope.launch {
            val words = withContext(Dispatchers.IO) { repository.getDictionaryWordsSnapshot() }
            val activeSnippets = withContext(Dispatchers.IO) { repository.getSnippetsSnapshot() }

            val aiResult = geminiService.reformatText(
                sourceText = trimmed,
                toneMode = currentSettings.selectedToneMode,
                dictionaryWords = words,
                snippets = activeSnippets,
                removeFillers = currentSettings.removeFillersEnabled,
                smartCorrections = currentSettings.smartCorrectionsEnabled
            )

            aiResult.onSuccess { result ->
                val entity = TranscriptEntity(
                    title = result.title,
                    rawTranscript = trimmed,
                    formattedText = result.formattedText,
                    toneModeId = currentSettings.selectedToneMode.id,
                    durationSeconds = 0
                )
                val insertedId = withContext(Dispatchers.IO) {
                    repository.saveTranscript(entity)
                }
                val saved = entity.copy(id = insertedId)
                val copied = if (currentSettings.autoCopyEnabled) {
                    ClipboardHelper.copyText(appContext, saved.formattedText)
                } else {
                    false
                }
                _dictationStage.value = DictationStage.Result(
                    transcript = saved,
                    wasAutoCopied = copied
                )
            }.onFailure { error ->
                _dictationStage.value = DictationStage.Error(
                    error.localizedMessage ?: "Could not format text."
                )
            }
        }
    }

    fun resetDictationStage() {
        _dictationStage.value = DictationStage.Idle
    }

    fun reformatHistoryTranscript(transcript: TranscriptEntity, targetTone: ToneMode) {
        val currentSettings = settings.value
        val sourceText = transcript.rawTranscript.ifBlank { transcript.formattedText }
        _reformattingHistoryId.value = transcript.id

        viewModelScope.launch {
            val words = withContext(Dispatchers.IO) { repository.getDictionaryWordsSnapshot() }
            val activeSnippets = withContext(Dispatchers.IO) { repository.getSnippetsSnapshot() }

            val aiResult = geminiService.reformatText(
                sourceText = sourceText,
                toneMode = targetTone,
                dictionaryWords = words,
                snippets = activeSnippets,
                removeFillers = currentSettings.removeFillersEnabled,
                smartCorrections = currentSettings.smartCorrectionsEnabled
            )

            _reformattingHistoryId.value = null

            aiResult.onSuccess { result ->
                val updated = transcript.copy(
                    title = result.title,
                    formattedText = result.formattedText,
                    toneModeId = targetTone.id
                )
                withContext(Dispatchers.IO) {
                    repository.updateTranscript(updated)
                }
                if (currentSettings.autoCopyEnabled) {
                    ClipboardHelper.copyText(appContext, updated.formattedText)
                    _snackbarMessage.value = "Re-formatted as ${targetTone.label} & copied"
                } else {
                    _snackbarMessage.value = "Re-formatted as ${targetTone.label}"
                }
            }.onFailure { error ->
                _snackbarMessage.value = error.localizedMessage ?: "Failed to re-format note."
            }
        }
    }

    fun copyText(text: String) {
        if (ClipboardHelper.copyText(appContext, text)) {
            _snackbarMessage.value = "Copied to clipboard"
        }
    }

    fun togglePinTranscript(transcript: TranscriptEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateTranscript(transcript.copy(isPinned = !transcript.isPinned))
        }
    }

    fun deleteTranscript(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteTranscript(id)
        }
        val stage = _dictationStage.value
        if (stage is DictationStage.Result && stage.transcript.id == id) {
            _dictationStage.value = DictationStage.Idle
        }
        _snackbarMessage.value = "Transcript deleted"
    }

    fun clearAllHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearHistory()
        }
        _snackbarMessage.value = "History cleared"
    }

    fun addDictionaryWord(word: String, hint: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addDictionaryWord(word, hint)
        }
        _snackbarMessage.value = "Added \"$word\" to Dictionary"
    }

    fun deleteDictionaryWord(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteDictionaryWord(id)
        }
    }

    fun addSnippet(triggerPhrase: String, expansionText: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addSnippet(triggerPhrase, expansionText)
        }
        _snackbarMessage.value = "Saved voice shortcut \"${triggerPhrase.trim()}\""
    }

    fun deleteSnippet(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteSnippet(id)
        }
    }

    fun setAutoCopyEnabled(enabled: Boolean) = settingsStore.setAutoCopyEnabled(enabled)
    fun setHapticsEnabled(enabled: Boolean) = settingsStore.setHapticsEnabled(enabled)
    fun setRemoveFillersEnabled(enabled: Boolean) = settingsStore.setRemoveFillersEnabled(enabled)
    fun setSmartCorrectionsEnabled(enabled: Boolean) = settingsStore.setSmartCorrectionsEnabled(enabled)

    fun startFloatingOverlay() {
        FloatingOverlayService.start(appContext)
        _snackbarMessage.value = "Floating mic bubble enabled"
    }

    fun stopFloatingOverlay() {
        FloatingOverlayService.stop(appContext)
        _snackbarMessage.value = "Floating mic bubble turned off"
    }

    override fun onCleared() {
        super.onCleared()
        viewModelScope.launch {
            audioEngine.cancelRecording()
        }
    }
}
