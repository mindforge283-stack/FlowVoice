package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val FlowVoiceDarkColorScheme = darkColorScheme(
    primary = ElectricIndigo,
    onPrimary = PureWhite,
    primaryContainer = ElectricIndigoContainer,
    onPrimaryContainer = ElectricIndigoBright,
    secondary = ElectricIndigoBright,
    onSecondary = ObsidianBackground,
    secondaryContainer = ObsidianSurfaceElevated,
    onSecondaryContainer = PureWhite,
    tertiary = EmeraldSuccess,
    onTertiary = ObsidianBackground,
    tertiaryContainer = EmeraldContainer,
    onTertiaryContainer = EmeraldSuccess,
    background = ObsidianBackground,
    onBackground = PureWhite,
    surface = ObsidianSurface,
    onSurface = PureWhite,
    surfaceVariant = ObsidianSurfaceElevated,
    onSurfaceVariant = SoftSlateText,
    surfaceContainerLow = ObsidianSurface,
    surfaceContainer = ObsidianSurfaceElevated,
    surfaceContainerHigh = ObsidianSurfaceHighest,
    outline = ObsidianOutline,
    outlineVariant = ObsidianOutlineSubtle,
    error = RecordingCoral,
    onError = PureWhite,
    errorContainer = RecordingCoralContainer,
    onErrorContainer = RecordingCoral
)

val FlowVoiceShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun FlowVoiceTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = FlowVoiceDarkColorScheme,
        typography = FlowVoiceTypography,
        shapes = FlowVoiceShapes,
        content = content
    )
}
