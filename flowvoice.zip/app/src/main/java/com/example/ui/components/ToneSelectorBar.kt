package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.FormatListBulleted
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChatBubbleOutline
import androidx.compose.material.icons.rounded.MailOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.ToneMode
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.ElectricIndigoBright
import com.example.ui.theme.ElectricIndigoContainer
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftSlateText

@Composable
fun ToneSelectorBar(
    selectedTone: ToneMode,
    onToneSelected: (ToneMode) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ToneMode.entries.forEach { mode ->
            val selected = mode == selectedTone
            val containerColor by animateColorAsState(
                targetValue = if (selected) ElectricIndigoContainer else ObsidianSurfaceElevated,
                label = "toneContainer"
            )
            val borderColor by animateColorAsState(
                targetValue = if (selected) ElectricIndigo else ObsidianOutline,
                label = "toneBorder"
            )
            val contentColor by animateColorAsState(
                targetValue = if (selected) PureWhite else SoftSlateText,
                label = "toneContent"
            )

            Surface(
                onClick = { if (enabled) onToneSelected(mode) },
                enabled = enabled,
                shape = RoundedCornerShape(14.dp),
                color = containerColor,
                border = BorderStroke(1.dp, borderColor),
                modifier = Modifier
                    .height(42.dp)
                    .minimumInteractiveComponentSize()
                    .testTag("tone_chip_${mode.id}")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = toneIcon(mode),
                        contentDescription = null,
                        tint = if (selected) ElectricIndigoBright else SoftSlateText,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = mode.label,
                        style = MaterialTheme.typography.labelLarge,
                        color = contentColor
                    )
                }
            }
        }
    }
}

fun toneIcon(mode: ToneMode): ImageVector {
    return when (mode) {
        ToneMode.CLEAN_NATURAL -> Icons.Rounded.AutoAwesome
        ToneMode.FORMAL_EMAIL -> Icons.Rounded.MailOutline
        ToneMode.CASUAL_CHAT -> Icons.Rounded.ChatBubbleOutline
        ToneMode.BULLET_POINTS -> Icons.AutoMirrored.Rounded.FormatListBulleted
    }
}
