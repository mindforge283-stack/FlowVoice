package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.TranscriptEntity
import com.example.data.model.ToneMode
import com.example.ui.components.toneIcon
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.ElectricIndigoBright
import com.example.ui.theme.ElectricIndigoContainer
import com.example.ui.theme.MutedSlateText
import com.example.ui.theme.ObsidianBackground
import com.example.ui.theme.ObsidianOutline
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceElevated
import com.example.ui.theme.PureWhite
import com.example.ui.theme.RecordingCoral
import com.example.ui.theme.SoftSlateText
import com.example.util.ClipboardHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    transcripts: List<TranscriptEntity>,
    reformattingId: Long?,
    onCopyText: (String) -> Unit,
    onReformatTranscript: (TranscriptEntity, ToneMode) -> Unit,
    onTogglePin: (TranscriptEntity) -> Unit,
    onDeleteTranscript: (Long) -> Unit,
    onClearAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilterTone by remember { mutableStateOf<ToneMode?>(null) }
    var inspectingTranscript by remember { mutableStateOf<TranscriptEntity?>(null) }
    var reformatPickerTarget by remember { mutableStateOf<TranscriptEntity?>(null) }

    val filteredTranscripts = remember(transcripts, searchQuery, selectedFilterTone) {
        transcripts.filter { item ->
            val matchesTone = selectedFilterTone == null || item.toneModeId == selectedFilterTone?.id
            val q = searchQuery.trim().lowercase()
            val matchesQuery = q.isEmpty() ||
                item.title.lowercase().contains(q) ||
                item.formattedText.lowercase().contains(q) ||
                item.rawTranscript.lowercase().contains(q)
            matchesTone && matchesQuery
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBackground)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 700.dp)
                .align(Alignment.TopCenter)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = stringResource(R.string.history_title),
                        style = MaterialTheme.typography.headlineMedium,
                        color = PureWhite
                    )
                    Text(
                        text = "${transcripts.size} saved offline on device",
                        style = MaterialTheme.typography.bodySmall,
                        color = SoftSlateText
                    )
                }

                if (transcripts.isNotEmpty()) {
                    TextButton(onClick = onClearAll) {
                        Text("Clear All", color = SoftSlateText)
                    }
                }
            }

            // Offline Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text(
                        text = stringResource(R.string.history_search_hint),
                        color = MutedSlateText
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Rounded.Search,
                        contentDescription = null,
                        tint = SoftSlateText
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(
                                imageVector = Icons.Rounded.Close,
                                contentDescription = "Clear search",
                                tint = SoftSlateText
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = ObsidianSurface,
                    unfocusedContainerColor = ObsidianSurface,
                    focusedBorderColor = ElectricIndigo,
                    unfocusedBorderColor = ObsidianOutline,
                    focusedTextColor = PureWhite,
                    unfocusedTextColor = PureWhite,
                    cursorColor = ElectricIndigoBright
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .testTag("history_search_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Filter Pills
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterPill(
                    label = "All",
                    selected = selectedFilterTone == null,
                    onClick = { selectedFilterTone = null }
                )
                ToneMode.entries.forEach { mode ->
                    FilterPill(
                        label = mode.label,
                        selected = selectedFilterTone == mode,
                        onClick = {
                            selectedFilterTone = if (selectedFilterTone == mode) null else mode
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (filteredTranscripts.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = ObsidianSurfaceElevated,
                            border = BorderStroke(1.dp, ObsidianOutline)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.History,
                                contentDescription = null,
                                tint = ElectricIndigoBright,
                                modifier = Modifier
                                    .padding(18.dp)
                                    .size(34.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (transcripts.isEmpty()) {
                                stringResource(R.string.history_empty_title)
                            } else {
                                "No matching transcripts"
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = PureWhite,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (transcripts.isEmpty()) {
                                stringResource(R.string.history_empty_body)
                            } else {
                                "Try a different keyword or clear the tone filter."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = SoftSlateText,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(filteredTranscripts, key = { it.id }) { item ->
                        val isReformatting = reformattingId == item.id
                        HistoryTranscriptCard(
                            transcript = item,
                            isReformatting = isReformatting,
                            onCardClick = { inspectingTranscript = item },
                            onCopy = { onCopyText(item.formattedText) },
                            onShare = { ClipboardHelper.shareText(context, item.formattedText, item.title) },
                            onReformat = { reformatPickerTarget = item },
                            onPinToggle = { onTogglePin(item) },
                            onDelete = { onDeleteTranscript(item.id) }
                        )
                    }
                }
            }
        }
    }

    // Detail Bottom Sheet
    inspectingTranscript?.let { activeItem ->
        val latestItem = transcripts.firstOrNull { it.id == activeItem.id } ?: activeItem
        var showRaw by remember(latestItem.id) { mutableStateOf(false) }

        ModalBottomSheet(
            onDismissRequest = { inspectingTranscript = null },
            containerColor = ObsidianSurface,
            contentColor = PureWhite
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 22.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = latestItem.title,
                        style = MaterialTheme.typography.headlineSmall,
                        color = PureWhite,
                        modifier = Modifier.weight(1f)
                    )
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = ElectricIndigoContainer
                    ) {
                        Text(
                            text = ToneMode.fromId(latestItem.toneModeId).label,
                            style = MaterialTheme.typography.labelMedium,
                            color = ElectricIndigoBright,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = formatTimestamp(latestItem.createdAt) +
                        if (latestItem.durationSeconds > 0) " · ${latestItem.durationSeconds}s" else "",
                    style = MaterialTheme.typography.labelSmall,
                    color = SoftSlateText
                )

                Spacer(modifier = Modifier.height(14.dp))

                if (latestItem.rawTranscript.isNotBlank() &&
                    latestItem.rawTranscript != latestItem.formattedText
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterPill(
                            label = "Cleaned",
                            selected = !showRaw,
                            onClick = { showRaw = false }
                        )
                        FilterPill(
                            label = "Original Spoken",
                            selected = showRaw,
                            onClick = { showRaw = true }
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = ObsidianSurfaceElevated,
                    border = BorderStroke(1.dp, ObsidianOutline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (showRaw) latestItem.rawTranscript else latestItem.formattedText,
                        style = MaterialTheme.typography.bodyLarge,
                        color = PureWhite,
                        modifier = Modifier.padding(16.dp)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            onCopyText(latestItem.formattedText)
                            inspectingTranscript = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricIndigo),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Rounded.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Copy")
                    }

                    FilledTonalButton(
                        onClick = {
                            reformatPickerTarget = latestItem
                            inspectingTranscript = null
                        },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = ObsidianSurfaceElevated,
                            contentColor = PureWhite
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .weight(1f)
                            .minimumInteractiveComponentSize()
                    ) {
                        Icon(
                            Icons.Rounded.AutoAwesome,
                            contentDescription = null,
                            tint = ElectricIndigoBright,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Re-format")
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Re-format Tone Picker Bottom Sheet
    reformatPickerTarget?.let { target ->
        ModalBottomSheet(
            onDismissRequest = { reformatPickerTarget = null },
            containerColor = ObsidianSurface,
            contentColor = PureWhite
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 22.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "Re-format \"${target.title}\"",
                    style = MaterialTheme.typography.titleLarge,
                    color = PureWhite
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Choose a tone & style to transform your saved transcript with Gemini:",
                    style = MaterialTheme.typography.bodySmall,
                    color = SoftSlateText
                )
                Spacer(modifier = Modifier.height(14.dp))

                ToneMode.entries.forEach { mode ->
                    Surface(
                        onClick = {
                            reformatPickerTarget = null
                            onReformatTranscript(target, mode)
                        },
                        shape = RoundedCornerShape(16.dp),
                        color = ObsidianSurfaceElevated,
                        border = BorderStroke(
                            1.dp,
                            if (target.toneModeId == mode.id) ElectricIndigo else ObsidianOutline
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp)
                            .minimumInteractiveComponentSize()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = toneIcon(mode),
                                contentDescription = null,
                                tint = ElectricIndigoBright,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = mode.label,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = PureWhite
                                )
                                Text(
                                    text = mode.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = SoftSlateText
                                )
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun FilterPill(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        color = if (selected) ElectricIndigoContainer else ObsidianSurfaceElevated,
        border = BorderStroke(1.dp, if (selected) ElectricIndigo else ObsidianOutline),
        modifier = Modifier.minimumInteractiveComponentSize()
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) PureWhite else SoftSlateText,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
        )
    }
}

@Composable
private fun HistoryTranscriptCard(
    transcript: TranscriptEntity,
    isReformatting: Boolean,
    onCardClick: () -> Unit,
    onCopy: () -> Unit,
    onShare: () -> Unit,
    onReformat: () -> Unit,
    onPinToggle: () -> Unit,
    onDelete: () -> Unit
) {
    val tone = ToneMode.fromId(transcript.toneModeId)

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = ObsidianSurface,
        border = BorderStroke(
            1.dp,
            if (transcript.isPinned) ElectricIndigo.copy(alpha = 0.6f) else ObsidianOutline
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onCardClick)
            .testTag("history_card_${transcript.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = ElectricIndigoContainer
                    ) {
                        Text(
                            text = tone.shortLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricIndigoBright,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = transcript.title,
                        style = MaterialTheme.typography.titleSmall,
                        color = PureWhite,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = onPinToggle,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.PushPin,
                        contentDescription = if (transcript.isPinned) "Unpin note" else "Pin note",
                        tint = if (transcript.isPinned) ElectricIndigoBright else MutedSlateText,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = transcript.formattedText,
                style = MaterialTheme.typography.bodyMedium,
                color = SoftSlateText,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formatTimestamp(transcript.createdAt) +
                        if (transcript.durationSeconds > 0) " · ${transcript.durationSeconds}s" else "",
                    style = MaterialTheme.typography.labelSmall,
                    color = MutedSlateText
                )

                if (isReformatting) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(
                            color = ElectricIndigoBright,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Re-formatting…",
                            style = MaterialTheme.typography.labelSmall,
                            color = ElectricIndigoBright
                        )
                    }
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        IconButton(onClick = onCopy) {
                            Icon(
                                imageVector = Icons.Rounded.ContentCopy,
                                contentDescription = "Copy transcript",
                                tint = PureWhite,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(onClick = onReformat) {
                            Icon(
                                imageVector = Icons.Rounded.AutoAwesome,
                                contentDescription = stringResource(R.string.history_reformat),
                                tint = ElectricIndigoBright,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(onClick = onShare) {
                            Icon(
                                imageVector = Icons.Rounded.Share,
                                contentDescription = "Share transcript",
                                tint = SoftSlateText,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        IconButton(onClick = onDelete) {
                            Icon(
                                imageVector = Icons.Rounded.DeleteOutline,
                                contentDescription = stringResource(R.string.history_delete),
                                tint = RecordingCoral.copy(alpha = 0.85f),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun formatTimestamp(timestampMs: Long): String {
    val formatter = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
    return formatter.format(Date(timestampMs))
}
