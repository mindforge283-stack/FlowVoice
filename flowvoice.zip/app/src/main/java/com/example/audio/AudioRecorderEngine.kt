package com.example.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sqrt

data class RecordedAudio(
    val wavBytes: ByteArray,
    val durationSeconds: Int
)

class AudioRecorderEngine {
    companion object {
        private const val TAG = "AudioRecorderEngine"
        private const val SAMPLE_RATE = 16_000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val WAVEFORM_BARS = 28
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val isRecordingFlag = AtomicBoolean(false)

    private var audioRecord: AudioRecord? = null
    private var captureJob: Job? = null
    private var pcmOutputStream: ByteArrayOutputStream? = null
    private var recordingStartTimeMs: Long = 0L

    private val _waveform = MutableStateFlow(List(WAVEFORM_BARS) { 0.08f })
    val waveform: StateFlow<List<Float>> = _waveform.asStateFlow()

    private val _currentAmplitude = MutableStateFlow(0f)
    val currentAmplitude: StateFlow<Float> = _currentAmplitude.asStateFlow()

    private val _elapsedSeconds = MutableStateFlow(0)
    val elapsedSeconds: StateFlow<Int> = _elapsedSeconds.asStateFlow()

    val isRecording: Boolean
        get() = isRecordingFlag.get()

    @SuppressLint("MissingPermission")
    fun startRecording(): Result<Unit> {
        if (isRecordingFlag.get()) {
            return Result.success(Unit)
        }

        val minBufferSize = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            CHANNEL_CONFIG,
            AUDIO_FORMAT
        )
        if (minBufferSize <= 0) {
            return Result.failure(IllegalStateException("Device microphone audio configuration is unavailable."))
        }

        val bufferSize = maxOf(minBufferSize * 2, SAMPLE_RATE / 5 * 2)

        return try {
            val recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                SAMPLE_RATE,
                CHANNEL_CONFIG,
                AUDIO_FORMAT,
                bufferSize
            )

            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder.release()
                return Result.failure(IllegalStateException("Could not initialize microphone recorder."))
            }

            pcmOutputStream = ByteArrayOutputStream()
            _waveform.value = List(WAVEFORM_BARS) { 0.08f }
            _currentAmplitude.value = 0f
            _elapsedSeconds.value = 0
            recordingStartTimeMs = System.currentTimeMillis()

            recorder.startRecording()
            audioRecord = recorder
            isRecordingFlag.set(true)

            captureJob = scope.launch {
                val readBuffer = ByteArray(bufferSize / 2)
                var lastBarUpdateMs = 0L

                while (isActive && isRecordingFlag.get()) {
                    val bytesRead = recorder.read(readBuffer, 0, readBuffer.size)
                    if (bytesRead > 0) {
                        synchronized(this@AudioRecorderEngine) {
                            pcmOutputStream?.write(readBuffer, 0, bytesRead)
                        }

                        val now = System.currentTimeMillis()
                        _elapsedSeconds.value = ((now - recordingStartTimeMs) / 1000L).toInt()

                        if (now - lastBarUpdateMs >= 45L) {
                            lastBarUpdateMs = now
                            val normalized = computeNormalizedRms(readBuffer, bytesRead)
                            _currentAmplitude.value = normalized
                            val updated = _waveform.value.drop(1) + maxOf(0.08f, normalized)
                            _waveform.value = updated
                        }
                    } else if (bytesRead < 0) {
                        Log.w(TAG, "AudioRecord.read returned error code: $bytesRead")
                    }
                }
            }

            Result.success(Unit)
        } catch (se: SecurityException) {
            Log.e(TAG, "Microphone permission denied", se)
            cleanupRecorder()
            Result.failure(se)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start recording", e)
            cleanupRecorder()
            Result.failure(e)
        }
    }

    suspend fun stopRecording(): RecordedAudio? = withContext(Dispatchers.IO) {
        if (!isRecordingFlag.getAndSet(false)) {
            return@withContext null
        }

        val duration = maxOf(1, ((System.currentTimeMillis() - recordingStartTimeMs) / 1000L).toInt())

        try {
            captureJob?.cancel()
            captureJob?.join()
        } catch (_: Exception) {
        }

        val pcmBytes: ByteArray
        synchronized(this@AudioRecorderEngine) {
            try {
                audioRecord?.stop()
            } catch (e: Exception) {
                Log.w(TAG, "Error stopping AudioRecord", e)
            }
            cleanupRecorder()
            pcmBytes = pcmOutputStream?.toByteArray() ?: ByteArray(0)
            pcmOutputStream = null
        }

        _currentAmplitude.value = 0f
        _waveform.value = List(WAVEFORM_BARS) { 0.08f }

        if (pcmBytes.isEmpty()) {
            return@withContext null
        }

        RecordedAudio(
            wavBytes = wrapPcmAsWav(pcmBytes),
            durationSeconds = duration
        )
    }

    suspend fun cancelRecording() = withContext(Dispatchers.IO) {
        if (!isRecordingFlag.getAndSet(false)) {
            return@withContext
        }
        try {
            captureJob?.cancel()
            captureJob?.join()
        } catch (_: Exception) {
        }
        synchronized(this@AudioRecorderEngine) {
            try {
                audioRecord?.stop()
            } catch (_: Exception) {
            }
            cleanupRecorder()
            pcmOutputStream = null
        }
        _currentAmplitude.value = 0f
        _elapsedSeconds.value = 0
        _waveform.value = List(WAVEFORM_BARS) { 0.08f }
    }

    private fun cleanupRecorder() {
        try {
            audioRecord?.release()
        } catch (_: Exception) {
        }
        audioRecord = null
    }

    private fun computeNormalizedRms(buffer: ByteArray, length: Int): Float {
        if (length < 2) return 0f
        var sumSquares = 0.0
        var sampleCount = 0
        var i = 0
        while (i + 1 < length) {
            val sample = ((buffer[i + 1].toInt() shl 8) or (buffer[i].toInt() and 0xFF)).toShort()
            val normalizedSample = sample / 32768.0
            sumSquares += normalizedSample * normalizedSample
            sampleCount++
            i += 2
        }
        if (sampleCount == 0) return 0f
        val rms = sqrt(sumSquares / sampleCount).toFloat()
        // Boost speech dynamic range smoothly into 0..1
        return ((rms * 4.5f).coerceIn(0f, 1f))
    }

    private fun wrapPcmAsWav(pcmData: ByteArray): ByteArray {
        val totalDataLen = pcmData.size + 36
        val byteRate = SAMPLE_RATE * 1 * 16 / 8
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(totalDataLen)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16) // Subchunk1Size for PCM
            putShort(1) // AudioFormat = PCM
            putShort(1) // NumChannels = Mono
            putInt(SAMPLE_RATE)
            putInt(byteRate)
            putShort(2) // BlockAlign = NumChannels * BitsPerSample / 8
            putShort(16) // BitsPerSample
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(pcmData.size)
        }.array()

        return header + pcmData
    }
}
